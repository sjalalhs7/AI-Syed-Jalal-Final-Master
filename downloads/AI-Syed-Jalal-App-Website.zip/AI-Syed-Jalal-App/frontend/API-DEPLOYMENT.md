# Cloudflare Pages API — Deployment and Operations

This application uses **Cloudflare Pages Functions** for its production HTTP API and **Neon PostgreSQL** for relational data. The deployed API entry point is:

`functions/api/[[path]].js`

The UI and Cloudflare-native API are deployed from the frontend directory configured in the Pages project. The separate recovered Node backend directory is not an independently deployed production service.

## Production configuration

Configure these values under **Cloudflare Dashboard → Workers & Pages → ai-syed-jalal-live → Settings → Variables and Secrets → Production**.

| Variable | Type | Requirement | Purpose |
|---|---|---|---|
| `DATABASE_URL` | Secret | Required | Neon connection string for the intended production database |
| `CSRF_SECRET` | Secret | Required | HMAC key; use a cryptographically random value of at least 32 characters |
| `SEED_ADMIN_PASSWORD` | Secret | Conditional | Initial/recovery administrator credential; use a unique password of 12–1,024 characters containing letters and numbers |
| `SEED_ADMIN_USERNAME` | Text | Conditional | Exact seed administrator username (3–40 letters, numbers, dots, underscores or hyphens) |
| `FIRST_ADMIN_SETUP_ENABLED` | Text | Normally absent or `false` | Only the exact value `true` enables initial Admin setup alongside the seed credentials; remove or disable immediately after authorized setup |
| `GEMINI_API_KEY` | Secret | Required for Gemini | Google Gemini provider authentication |
| `OPENAI_API_KEY` | Secret | Optional | OpenAI provider authentication |
| `ANTHROPIC_API_KEY` | Secret | Optional | Anthropic provider authentication |
| `DEEPSEEK_API_KEY` | Secret | Optional | DeepSeek provider authentication |
| `OMNIROUTE_API_KEY` / `OMNIROUTE_KEY` | Secret | Optional | OmniRoute authentication |
| `OMNIROUTE_BASE_URL` / `OMNIROUTE_URL` | Text | Optional with OmniRoute | HTTPS base URL for the OmniRoute-compatible API |

Set optional model variables only when intentionally overriding the defaults: `GEMINI_MODEL`, `OPENAI_MODEL`, `ANTHROPIC_MODEL`, `DEEPSEEK_MODEL`, and `OMNIROUTE_MODEL`.

First-administrator setup is disabled unless the operator explicitly sets `FIRST_ADMIN_SETUP_ENABLED` to `true` **and** configures both seed values. It accepts only that exact username and password, is unavailable while any Administrator account exists (including inactive accounts), and uses the shared rate limiter. If the limiter or trusted client IP is unavailable, setup fails closed. An existing account must also match its stored password before promotion. Setup creates or promotes the account and issues its initial session in one database statement; concurrent promotion of the same account is conditional on the previously verified role and credentials. Disable the setup switch after the authorized operation and use a separately reviewed recovery procedure for inactive Administrators. This is not a permanent one-time seal: if all Admin roles are removed and the switch and seed remain configured, setup may reopen. It is also not a global atomic constraint across concurrent account-role changes. Ordinary sign-in for existing accounts does not require the setup switch. The login route retains a separate seed-based password recovery path for an existing active Admin, so a configured seed remains a sensitive recovery credential even after initial setup and after an ordinary password change. The operator should decide when to remove it, after confirming another safe recovery method; do not remove it blindly or post it in chat. These code and documentation changes do not change deployment settings or migrate a database.

The optional OmniRoute adapter requires **both** a server-side key and an HTTPS endpoint. JARVIS and JalalAi report it as configured when both values are nonblank; the adapter rejects an invalid or non-HTTPS endpoint before making a request. The deployment-controlled endpoint may forward submitted text to another provider. Confirm its privacy terms and possible charges before enabling it. Key and endpoint presence do not prove that authentication or a model request succeeds.

Never put credentials in source control, frontend JavaScript, screenshots, issue reports, or build logs. Do not copy production secret values into documentation.

## Free accounts and shared access

The first-party username/password sign-up has no authentication-provider subscription, email verification, or payment step. It still requires a working database and a `CSRF_SECRET`; hosting, database capacity and optional AI services can have separate costs. Social sign-in and self-service password recovery are **not implemented**. Users should save their username and password securely. Password changes require the current password; there is no general reset flow for a forgotten Viewer password.

**Public sign-ups become Viewers of the existing shared workspace.** They can read existing active records, including record notes, and pending approvals, including their actions, descriptions and requester names—not just items they created. Any signed-in role can list up to 100 pending approvals, oldest first, through the API; only Admins and Managers can create or resolve them. The Workspace approvals screen is limited to Admins and Managers, but hiding that screen does not restrict API access. The owner chose to keep that shared access. Anyone able to register can receive it. Viewer accounts cannot write Data Vault records or use Admin endpoints, but this is not private-account isolation. Review the sensitivity of existing records and pending approvals. Assistant tasks and notes have their own account-scoped routes; do not assume every feature is private merely because some are account-scoped.

**Selected diagnostic and catalogue policy.** Disposable tests of this source verify that `/api/stats` is Admin-only; it includes shared record breakdowns, active-account totals and audit-event counts, but not the audit-event list. The active-account count is not a count of active sessions. Any signed-in role can run Expert Critic, including through its chat entry point, but only Admin reviews include workspace-wide aggregates. Other roles receive account-scoped audit/session, run/failure, self-check, Arena, and timing evidence; cross-account rate-limit and orphan counts are omitted. Saved review history and individual agent-run routes remain account-scoped. The review POST requires CSRF. Do not assume these are the only shared data paths.
- `GET /api/agent/skills` is read-only: it checks that the catalogue table exists and returns stored entries (or uses the bundled search index), but never writes shared catalogue rows. Only an Admin can explicitly synchronize bundled skill fields through the CSRF-protected, per-user rate-limited `POST /api/agent/skills`; the Agent Lab exposes this as an Admin-only action. Self-checks do not synchronize the catalogue. They still attempt an insert/read/delete audit probe; an interrupted probe may leave a test row, and the result is stored on the requesting account. None of these operations allows a Viewer to submit arbitrary Data Vault record changes.

Review the sensitivity and load implications of these behaviors before relying on public registration. The owner's decision to share pending approvals remains separate from the diagnostic and catalogue policies above. The isolated 13-table-name fixture was not a live schema clone or proof of production behavior.

Viewer access to configured cloud AI is unchanged. Provider requests may charge the owner. Per-user request limits and the per-IP registration limiter are not a spending cap and do not prevent distributed sign-ups. Set and monitor provider-side budgets and quotas separately; local tools do not need a provider key. No email, social or paid authentication provider is contacted by sign-up.

Registration counts every attempt using the database-backed token bucket, independent of best-effort audit writes: an initial burst of 10 attempts per trusted edge IP, then one attempt replenished every 360 seconds. Missing trusted IP, unavailable limiter, or missing session/CSRF secret fails closed. Login has its own limiter. Shared networks can hit these limits and should wait before retrying; they are not comprehensive bot protection. Sign-up, sign-in and first-Admin setup POSTs require JSON rather than accepting cross-site HTML form submissions.

New public and Admin-created usernames are stored in lowercase. The API rejects case-insensitive matches to existing names, including inactive accounts; its existing case-sensitive unique constraint arbitrates simultaneous new API sign-ups. Login first tries the exact spelling, then permits a case-insensitive match only if exactly one account (active or inactive) has that spelling ignoring case. Ambiguous legacy accounts continue to require their exact capitalization. A valid configured seed username is reserved against public sign-up, and seed recovery remains exact. Existing usernames and roles are not rewritten. This is not a database-wide case-insensitive uniqueness constraint: direct database writes, older servers, or concurrent configuration changes can still introduce case variants. Any proposed unique index requires collision review, backup, isolated rehearsal, and explicit operator authorization; these source changes do not apply one.

Account creation and the initial session are inserted in one database statement so a failed session insert does not leave an unusable new account. A lost response can still leave the outcome unknown: try signing in before attempting to register the same username again. The browser confirms the resulting session before navigating. First-Admin setup also verifies the new session before navigation; if its response is lost or unverifiable, setup may already have finished, so check sign-in and the account before trying again.

### Passwords, sessions and connection changes

Workspace Settings lets a signed-in user change their password with the current password and review or revoke other sessions. A successful password change updates credentials and revokes other sessions in one `READ COMMITTED` database transaction; the requesting session is not revoked by that action. It rechecks that the requesting session is active at the credential-update statement's snapshot. Revocation does not cancel requests already running concurrently, which may still finish. A seed recovery instead rotates credentials, revokes all existing sessions and creates the recovery session in one transaction. These actions fail closed if transaction support is unavailable. Ordinary login and initial setup condition session creation on the account state they verified. The account password-change limiter uses an independent database bucket: an initial five attempts, refilling one every 300 seconds. It returns 429 with `Retry-After: 300` when exhausted and 503 if the limiter is unavailable. It is not a substitute for protecting the session cookie.

**A lost or timed-out response can be uncertain even if the server committed.** The Workspace retains the fields and requires acknowledgement before another change, but that acknowledgement is only in memory; a confirmed success clears the fields. Do not immediately repeat a password change: carefully test the new password by signing in separately, then test the old one if needed. An earlier request that is still running could still finish later. Keep the current session open while checking, and contact the deployment owner if neither credential works. If revocation is uncertain, refresh the session list. The list contains at most the latest 100 session rows, including revoked or expired entries; an older current session may not appear, and it does not identify devices or locations. `DELETE /api/auth/sessions` revokes the account's other sessions, not the current one.

The Workspace API connection setting is staged for the next sign-in and only committed to the shared setting after a verified login. A verified Workspace endpoint is also remembered in that tab for reloads, when browser session storage is available; without that tab setting it starts at the website origin instead of following an old shared override. Some other pages use the shared setting and others prefer the website origin. A verified homepage sign-in, sign-up or first-Admin setup sets both settings back to this website's origin and clears a staged next endpoint. Testing an endpoint sends a credential-free health request, not a login; it does not establish data access. Custom cross-origin APIs need compatible credentialed CORS and cookie policies; this Pages API does not grant cross-origin CORS access. Only sign in to an API endpoint you trust. Mocked browser tests do not establish interoperability with a real custom service.

The password/seed-recovery Neon HTTP transaction request shape is covered using a mocked SDK transport, and the lock ordering is covered against disposable PostgreSQL. Neither test contacts Neon or proves a particular deployed database's behavior. Confirm deployment and exercise authorized account flows in a safe environment before making production-readiness claims.

## Implemented API surface

The current Pages Function contains these routes:

| Route | Method | Purpose |
|---|---|---|
| `/api/health` | GET | Database connectivity check |
| `/api/ready` | GET | Readiness check for the required database tables |
| `/api/version` | GET | Application/API release metadata |
| `/api/auth/register` | POST | User registration |
| `/api/auth/login` | POST | Session creation |
| `/api/auth/logout` | POST | CSRF-protected session revocation |
| `/api/auth/change-password` | POST | Current-password- and CSRF-protected password change; revoke other sessions |
| `/api/auth/sessions` | GET, DELETE | List up to 100 account sessions; CSRF-protected revocation of other sessions |
| `/api/csrf` | GET | Authenticated CSRF token |
| `/api/me` | GET | Current authenticated user |
| `/api/chat` | POST | Compatibility alias for the AI execution route |
| `/api/ai/run` | POST | Provider-backed text/image prompt execution |
| `/api/ai/runs` | GET | Current user's AI run history |
| `/api/ai/capabilities` | GET | Authenticated provider and agent capability catalogue |
| `/api/admin/ai/overview` | GET | Admin-only AI usage summary |
| `/api/admin/ai/provider-health` | GET | Admin-only provider configuration status |
| `/api/admin/diagnostics` | GET | Admin-only schema diagnostics |
| `/api/admin/audit` | GET | Admin-only audit event listing |
| `/api/records` | GET, POST | Record listing and creation |
| `/api/records/:id` | GET, PUT, DELETE | Record retrieval, update, and soft deletion |
| `/api/meta` | GET | Record filter metadata |
| `/api/stats` | GET | Admin-only shared record statistics, active-account and audit-event totals |
| `/api/agent/skills` | GET, POST | Read-only shared catalogue browsing; explicit CSRF-protected POST sync is Admin-only and rate-limited |
| `/api/assistant/critic/review` | GET, POST | Account-scoped saved review; only Admin-generated reviews contain deployment-wide aggregates |
| `/api/approvals` | GET, POST | List pending approvals; Admin/Manager may request a recorded decision |
| `/api/approvals/:id` | PATCH, POST | Admin/Manager may approve or reject a pending decision |
| `/api/assistant/*` | GET, POST, PATCH, DELETE | Authenticated local/cloud assistant, confirmed tasks/notes and state |
| `/api/platform/*` | GET, POST, PATCH, DELETE | Agent Studio conversations, messages, transient history and compare votes |

Unimplemented routes return HTTP 501 with `ROUTE_NOT_IMPLEMENTED`; routes whose storage is missing may return 503 or another error. A route appearing in the recovered source tree is not proof that it is deployed or production-ready.

## AI capability boundaries

The Cloudflare endpoint executes provider-backed prompts through configured provider APIs. Gemini is the default provider when no provider is specified. A configured key is only evidence that a secret is present; it is **not** proof of successful provider authentication or a successful model response.

The recovered agent catalogue and skill metadata do not mean that every listed agent has an independent tool runtime. Voice capture/synthesis, external browsing, autonomous external actions, and specialist integrations must not be represented as active unless their dedicated runtime is implemented and tested.

## Security and operational behavior

- Sessions use an HTTP-only, Secure, SameSite=Lax cookie.
- Protected POST, PUT, PATCH and DELETE requests require a valid CSRF token. Skill-catalogue browsing GET is read-only; synchronization uses an explicit Admin-only, CSRF-protected POST.
- Passwords are stored as derived hashes; never log or return passwords, tokens, or secret values.
- Registration, login, password changes and AI execution have server-side rate limits.
- Request bodies are size-limited and JSON parsing errors are handled.
- Admin-only routes enforce the Admin role.
- API responses set no-store and baseline browser security headers.

## Verification procedure

Run from the recovered application directory (`source/AI-Syed-Jalal-FINAL-RECOVERED`):

```bash
npm ci
npm run check
npm test
npm run test:e2e
npm run build
```

The browser suite uses an isolated local database and speech/provider doubles; it is not a real device or live-provider test. The application workflow also runs the password/session race tests against a disposable PostgreSQL 16 service and requires a test URL instead of silently skipping. `server/tests/postgres-password-concurrency.test.mjs` otherwise skips without its dedicated `AJ_PASSWORD_PG_TEST_URL`. Run it only against an independently created, disposable loopback service using user `aj_password_test` and database `aj_password_race_test`; it creates and drops a random schema. The CI service explicitly opts in to a private-container server address. Never point this test at a forwarded production database.

A merge does not itself prove that Cloudflare Pages deployed. PR #73's generated
squash message inherited an automation-skip directive from an older commit;
normal push workflows did not run, no Cloudflare Pages build was observed, and
an initial post-merge check found the Android association absent on the live
origin. When deployment is intended, review the entire squash message and use
a clean message without automation-skip directives. Verify the Cloudflare
Pages build for the actual main commit and then check the live origin. A
successful GitHub Pages build or branch preview is not proof that the live
Cloudflare site changed. Deploying source does not authorize database repair.

The `Android launch regression` workflow checks the live Android association
on relevant main-branch pushes. To recheck only that public, read-only JSON
without rebuilding the APK, dispatch the workflow from `main` with
`association_only` set to `true`, for example:

```bash
gh workflow run android-launch-diagnostics.yml --ref main -f association_only=true
```

The job checks for HTTP 200 without a redirect, JSON content type, and a parsed
body matching the main-branch file. An association-only dispatch from another
branch fails rather than silently reporting a production check. A passing
association check alone does not prove database readiness, sign-in, Android
installation, Play Protect behavior, or all website features.

After deployment:

1. Read `GET /api/health` for database connectivity and `GET /api/ready` for the required table-name inventory. A ready response has `ready: true` and `schemaTables` equal to `required` (currently 24). This checks names only, not columns, indexes, migration history, data or provider behavior. A connected database alone is not readiness.
2. If readiness is incomplete, do not automatically migrate or repair production. First identify the actual target, verify a restorable full backup, rehearse the intended repair on an isolated clone, and obtain explicit operator approval. See [Production database safety](../../../docs/PRODUCTION-DATABASE-SAFETY.md).
3. Exercise authentication, CSRF, record CRUD, approvals, role restrictions, Agent Studio history/transient mode, attachments and compare voting on an isolated non-production deployment using test data. Those results do not themselves prove the production configuration.
4. With the owner's approval and awareness of provider costs, use a non-sensitive prompt to check that the intended deployed provider returns a real response with `status: "completed"` and `simulated: false`. Check provider failures, absent configuration and unauthorised access safely. A successful response proves only that particular request; it does not validate voice on a physical device.

Do not run destructive tests against production data. Record which deployment, test data, provider and device were actually exercised; do not mark the release fully verified from local or simulated results alone.

## Known gaps requiring separate implementation

The current Pages Function includes records backup/merge restore, administrative user management and a skills/library catalogue. Restore is a records merge, not a full tenant/database disaster-recovery restore. Unknown routes return 501. Live production verification still requires the configured Neon database, migrations, secrets and staging checks below.

The separate recovered backend directory is retained in the repository for reference; it is not automatically part of the Cloudflare Pages deployment. Cloudflare Pages is the production API runtime for this configuration. No Render service is required for the current architecture.
