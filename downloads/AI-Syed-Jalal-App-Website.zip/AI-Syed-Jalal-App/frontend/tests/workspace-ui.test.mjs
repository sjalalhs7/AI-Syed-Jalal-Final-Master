import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const read = (name) => readFile(join(root, name), 'utf8');
const [workspace, dashboard, homepage] = await Promise.all([
  read('workspace.html'), read('dashboard.html'), read('index.html')
]);

test('workspace does not expose demo login or simulated mission screens', () => {
  for (const marker of ['demoBtn', 'demo://local', 'demoApprovals', 'newMissionBtn',
    'view-missions', 'view-dashboard', 'view-agents', 'view-analytics', 'view-control']) {
    assert.equal(workspace.includes(marker), false, 'unexpected demo/mock UI marker: ' + marker);
  }
});

test('every workspace navigation target has a real view', () => {
  const targets = [...workspace.matchAll(/data-nav="([^"]+)"/g)].map((m) => m[1]);
  const views = new Set([...workspace.matchAll(/id="view-([^"]+)"/g)].map((m) => m[1]));
  assert.ok(targets.length > 0);
  for (const target of targets) assert.ok(views.has(target), 'missing workspace view: ' + target);
});

test('dashboard agent deep links open the actual agent catalogue', () => {
  assert.match(dashboard, /id="v-agents"/);
  assert.match(dashboard, /const requestedView=location\.hash\.slice\(1\)/);
  assert.ok(dashboard.includes('includes(requestedView))view(requestedView)'));
});

test('homepage advertises working tools, not unverified integrations', () => {
  for (const href of ['workspace.html#ai-command', 'dashboard.html#agents',
    'workspace.html#data', 'workspace.html#documents', 'visual-styles.html',
    'roadmaps.html', 'workspace.html#operations']) {
    assert.ok(homepage.includes(href), 'missing working tool link: ' + href);
  }
  for (const marker of ['OmniRoute', 'Omniverse', 'Voice Agent', 'Health Agent',
    'Knowledge Vault', 'Mission Orchestrator', 'OpenGPT Assistant',
    'Automation Agent', 'visual-library.html', 'projects.html']) {
    assert.equal(homepage.includes(marker), false, 'unverified launch remains: ' + marker);
  }
});

test('Viewer AI console does not depend on Admin-only endpoints', () => {
  const start = workspace.indexOf('async function renderAICommand()');
  const end = workspace.indexOf('function loadConnection()', start);
  assert.ok(start >= 0 && end > start);
  const loader = workspace.slice(start, end);
  assert.match(loader, /Promise\.all\(\[api\('\/api\/ai\/capabilities',\{signal:timeoutSignal\(15000\)\}\),api\('\/api\/ai\/runs\?limit=8',\{signal:timeoutSignal\(15000\)\}\)\]\)/);
  assert.match(loader, /state\.role==='Admin'/);
  assert.equal(loader.includes("api('/api/admin/ai/provider-health')"), false);
});

test('Dashboard security and audit navigation is restricted to Admin', () => {
  assert.match(dashboard, /currentRole=me\.role/);
  assert.match(dashboard, /secNav\.hidden=me\.role!=='Admin'/);
  assert.match(dashboard, /if\(v==='sec'&&currentRole!=='Admin'\)return/);
  assert.match(dashboard, /Admin only\. This section is hidden for other roles\./);
});

test('Data Vault exports central API records rather than the local IndexedDB store', () => {
  assert.match(workspace, /async function fetchAllCentralRecords\(\)/);
  assert.match(workspace, /api\('\/api\/records\?page='\+page\+'&limit=200'\)/);
  assert.match(workspace, /async function rowsForExport\(\)\{return remoteMode\(\)\?await fetchAllCentralRecords\(\):await all\(STORE\)\}/);
  const exportHandler = workspace.slice(workspace.indexOf("$('#exportBtn').onclick="), workspace.indexOf("$('#backupBtn').onclick="));
  assert.equal(exportHandler.includes('all(STORE)'), false);
});

test('Workspace hides write, backup, and Admin-only controls according to role', () => {
  assert.match(workspace, /const canWrite=\['Admin','Manager','Data Operator'\]\.includes\(state\.role\)/);
  assert.match(workspace, /\$\('#backupBtn'\)\.hidden=state\.role!=='Admin'/);
  assert.match(workspace, /\['operations','users'\]\.includes\(view\)&&state\.role!=='Admin'/);
  assert.match(workspace, /id="view-approvals"/);
  assert.match(workspace, /async function renderApprovals\(\)/);
  assert.match(workspace, /\['Admin','Manager'\]\.includes\(state\.role\)/);
  assert.match(workspace, /data-approval-action/);
});

test('Operations Center labels only metrics the Pages runtime actually exposes', () => {
  assert.ok(workspace.includes('AI runs (24h):'));
  assert.ok(workspace.includes('Edge uptime, database pool connections, queue depth and concurrency are not exposed'));
  assert.ok(workspace.includes('Neon pool statistics and edge process uptime are unavailable'));
  assert.equal(workspace.includes('met.process.uptimeSeconds'), false);
  assert.equal(workspace.includes('snap.pool.total'), false);
});

test('Dashboard runs only configured providers and describes profiles honestly', () => {
  assert.match(dashboard, /Supported text profiles/);
  assert.match(dashboard, /AI Prompt Profiles/);
  assert.match(dashboard, /These are not autonomous agents/);
  assert.ok(dashboard.includes("$('#qgo').disabled=$('#go').disabled=$('#dashboardEngine').value==='cloud'&&!first"));
  assert.match(dashboard, /No AI provider key is configured/);
  assert.match(dashboard, /live test required/);
});

test('Connection page cannot locally assign server roles or fake a tenant', () => {
  assert.equal(workspace.includes('id="roleSelect"'), false);
  assert.equal(workspace.includes('id="tenantId"'), false);
  assert.equal(workspace.includes('Role selection is a local UI contract'), false);
  assert.equal(workspace.includes('GitHub Pages remains the static frontend'), false);
  assert.ok(workspace.includes('Account roles are assigned by the server'));
  assert.ok(workspace.includes('Sign in with your username and password.'));
  assert.ok(workspace.includes('Free sign-ups are Viewers who can read shared active records and their notes.'));
  assert.ok(workspace.includes('Pending approvals, including descriptions and requester names, are readable through the API.'));
  assert.ok(workspace.includes('active account and audit-event counts'));
  assert.ok(workspace.includes('Expert Critic includes deployment-wide aggregate diagnostics for Admins; other roles see account-scoped review evidence.'));
});

test('Workspace cloud provider selection follows the API metadata', () => {
  assert.match(workspace, /providerSelect\.innerHTML=providers\.map/);
  assert.match(workspace, /No provider key configured/);
});

test('Workspace gates cloud and pending requests while permitting ready local tools', () => {
  assert.ok(workspace.includes("['#aiRunBtn','#runSupervisorBtn','#runAutoGPTBtn'].forEach(q=>{if($(q))$(q).disabled=true})"));
  assert.ok(workspace.includes('providerSelect.disabled=!selected'));
  assert.ok(workspace.includes("$('#runSupervisorBtn').disabled=!selected;$('#runAutoGPTBtn').disabled=!selected"));
  assert.ok(workspace.includes("$('#aiRunBtn').disabled=Boolean(aiRunController)||!remoteMode()||!aiInventoryReady||($('#aiEngine').value==='cloud'&&$('#aiProviderSelect').disabled)"));
});

test('Homepage does not market unimplemented autonomous, voice or multi-model features', () => {
  for (const marker of ['Ultimate Power Agent', 'AI Agents', 'voice assistant',
    'image and voice tools', 'multi-model workflows', '360° AI COMMAND CENTER',
    'THINK · BUILD · AUTOMATE']) {
    assert.equal(homepage.toLowerCase().includes(marker.toLowerCase()), false,
      'unsupported homepage claim remains: ' + marker);
  }
  assert.ok(homepage.includes('AI WORKSPACE · PLAN · BUILD · ORGANIZE'));
  assert.ok(homepage.includes('open-ended AI chat needs a working, configured provider.'));
});

test('Workspace metadata points to Cloudflare and does not retain GitHub Pages SEO claims', () => {
  const absoluteUrls = [...workspace.matchAll(/https?:\/\/[^"'\s<>]+/g)].map(([value]) => new URL(value));
  assert.equal(absoluteUrls.some(url => url.hostname === 'github.io' || url.hostname.endsWith('.github.io')), false);
  assert.equal(workspace.includes('class=\"seo-discovery\"'), false);
  assert.ok(absoluteUrls.some(url => url.origin === 'https://ai-syed-jalal-live.pages.dev' && url.pathname === '/workspace.html'));
  assert.ok(workspace.includes('central Neon records'));
});

test('Admin account mutations are single-flight, bounded, and disclose uncertain outcomes', () => {
  const start = workspace.indexOf('let usersRenderGeneration=0;');
  const end = workspace.indexOf("$('#opsBackupBtn')?.addEventListener", start);
  assert.ok(start >= 0 && end > start);
  const users = workspace.slice(start, end);
  assert.ok(users.includes("signal:timeoutSignal(15000)"), 'user-list and account mutations have bounded waits');
  assert.ok(users.includes('let userCreatePending=false') && users.includes('if(userCreatePending)return'));
  assert.ok(users.includes('const userStatusPending=new Set()') && users.includes('if(userStatusPending.has(id))return'));
  assert.ok(users.includes('The create result is uncertain') && users.includes('Do not retry yet'));
  assert.ok(users.includes('Status result uncertain') && users.includes('await renderUsers()'));
  assert.ok(users.includes('status>=500'), 'server failures after a possible commit are handled as uncertain');
});
