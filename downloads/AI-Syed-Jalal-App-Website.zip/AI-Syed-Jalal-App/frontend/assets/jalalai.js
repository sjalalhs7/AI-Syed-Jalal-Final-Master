'use strict';
(() => {
  const $ = id => document.getElementById(id);
  let user = null, csrf = '', busy = false, recognition = null, listening = false, speech = null, lastReply = '', state = { tasks: [], notes: [] }, requestController = null, providerTouched = false, savedListsHidden = false, savedViewVersion = 0, sessionVersion = 0;
  const setStatus = text => { $('status').textContent = text; };
  async function api(path, options = {}, timeoutMs = 65000) {
    const headers = { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(csrf && options.method && options.method !== 'GET' ? { 'X-CSRF-Token': csrf } : {}), ...options.headers };
    // Compose Stop and timeout without relying on newer AbortSignal statics.
    // The deadline covers the body as well as the response headers.
    const request = new AbortController(), caller = options.signal;
    const forwardAbort = () => request.abort();
    if (caller?.aborted) forwardAbort();
    else caller?.addEventListener('abort', forwardAbort, { once: true });
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; request.abort(); }, timeoutMs);
    try {
      const response = await fetch('/api' + path, { ...options, headers, credentials: 'same-origin', signal: request.signal });
      const data = await response.json().catch(error => {
        if (request.signal.aborted || error?.name !== 'SyntaxError') throw error;
        if (response.ok) throw new Error('The application response was unreadable. The server may still finish; check before retrying.');
        return {};
      });
      if (request.signal.aborted) throw Object.assign(new Error('Request aborted.'), { name: 'AbortError' });
      if (!response.ok) { const error = new Error(data?.error || `Request failed (${response.status})`); error.status = response.status; error.code = data?.code; throw error; }
      return data;
    } catch (error) {
      if (timedOut) throw Object.assign(new Error('The request timed out. The server may still finish; check before retrying.'), { name: 'TimeoutError' });
      throw error;
    } finally {
      clearTimeout(timer);
      caller?.removeEventListener('abort', forwardAbort);
    }
  }
  function requireAssistantResponse(result) {
    if (result?.ok !== true || typeof result.output !== 'string' || !result.output.trim()) {
      throw new Error('The application response was incomplete. The server may still finish; check history or saved actions before retrying.');
    }
    return result;
  }
  function requireSavedAction(data, action) {
    const isTask = action?.type === 'create_task', isNote = action?.type === 'create_note';
    const saved = isTask ? data?.task : isNote ? data?.note : null;
    const matches = isTask ? saved?.title === action.title : isNote && saved?.content === action.content;
    if (data?.ok !== true || typeof data.output !== 'string' || !data.output.trim() || typeof saved?.id !== 'string' || !saved.id || !matches) {
      throw new Error('The save response could not be verified.');
    }
    return data;
  }
  function cloudStatusUnknown() {
    const value = state.cloudProviders?.[$('provider').value];
    return $('mode').value === 'cloud' && value !== true && value !== false;
  }
  function updateControls() {
    $('sendBtn').disabled = !user || busy || cloudStatusUnknown() || !$('prompt').value.trim();
    $('micBtn').disabled = !user || busy;
    $('readBtn').disabled = !lastReply;
    $('stopBtn').disabled = !busy && !listening && !window.speechSynthesis?.speaking;
    $('showSavedListsBtn').disabled = !user || busy;
    $('accountBtn').textContent = user ? 'Sign out' : 'Sign in';
  }
  function stopVoice() {
    if (recognition) { recognition.onend = null; try { recognition.abort(); } catch {} recognition = null; }
    listening = false; $('micBtn').textContent = '🎙 Speak'; $('micBtn').setAttribute('aria-pressed', 'false');
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    updateControls();
  }
  function speak(text) {
    if (!('speechSynthesis' in window)) { setStatus('Speech output is not supported by this browser. The reply remains available as text.'); return; }
    window.speechSynthesis.cancel();
    speech = new SpeechSynthesisUtterance(text.slice(0, 5000)); speech.lang = $('speechLanguage').value || 'en-US';
    if (window.AJSpeech) window.AJSpeech.apply(speech, { lang: speech.lang });
    else {
      const voices = window.speechSynthesis.getVoices();
      const voice = voices.find(v => v.lang.replace('_', '-').toLowerCase() === speech.lang.toLowerCase()) || voices.find(v => v.lang.startsWith(speech.lang.split('-')[0]));
      if (voice) speech.voice = voice;
    }
    speech.onend = speech.onerror = () => { speech = null; updateControls(); };
    window.speechSynthesis.speak(speech); updateControls();
  }
  function addMessage(text, role = 'assistant', meta = 'JalalAi · local tools', result = null) {
    const node = document.createElement('div'); node.className = 'message ' + role;
    const label = document.createElement('div'); label.className = 'meta'; label.textContent = meta; node.appendChild(label);
    const content = document.createElement('span'); content.textContent = text; node.appendChild(content);
    if (role === 'assistant') {
      const actions = document.createElement('div'); actions.className = 'message-actions';
      const read = document.createElement('button'); read.type = 'button'; read.className = 'btn small'; read.textContent = 'Read aloud'; read.onclick = () => speak(text); actions.appendChild(read); if (window.AJReport) actions.appendChild(window.AJReport.button(text, 'jalalai')); node.appendChild(actions);
      lastReply = text;
    }
    if (result?.action) {
      const box = document.createElement('div'); box.className = 'confirmation';
      const prompt = document.createElement('p'); prompt.textContent = result.action.type === 'create_task' ? `Save task: ${result.action.title}` : `Save private note: ${result.action.content}`;
      const confirm = document.createElement('button'); confirm.className = 'btn small primary'; confirm.type = 'button'; confirm.textContent = 'Confirm & save';
      const cancel = document.createElement('button'); cancel.className = 'btn small'; cancel.type = 'button'; cancel.textContent = 'Cancel'; cancel.style.marginLeft = '8px';
      confirm.onclick = async () => {
        confirm.disabled = cancel.disabled = true; setStatus('Saving your confirmed action…');
        const saveSession = sessionVersion;
        let data;
        try {
          data = requireSavedAction(await api('/assistant/confirm', { method: 'POST', body: JSON.stringify({ confirmed: true, action: result.action }) }, 20000), result.action);
        } catch (error) {
          // A lost response does not prove the write failed. Remove this
          // confirmation so another tap cannot immediately duplicate the save.
          if (saveSession !== sessionVersion || !box.isConnected) return;
          const message = 'Could not verify the save. The server may still finish; check your tasks or notes before trying again.';
          box.replaceChildren(document.createTextNode(message)); setStatus(message); return;
        }
        if (saveSession !== sessionVersion || !box.isConnected) return;
        box.replaceChildren(document.createTextNode(data.output)); setStatus('Saved after your confirmation.');
        try { await refreshState(); }
        catch { box.appendChild(document.createTextNode(' The save was confirmed, but the saved lists could not refresh.')); }
      };
      cancel.onclick = () => { box.replaceChildren(document.createTextNode('Cancelled. Nothing was saved.')); };
      box.append(prompt, confirm, cancel); node.appendChild(box);
    }
    $('chatlog').appendChild(node); $('chatlog').scrollTop = $('chatlog').scrollHeight; updateControls();
    return node;
  }
  function renderSavedList(id, items, kind) {
    const list = $(id); list.replaceChildren();
    if (!items.length) { const empty = document.createElement('li'); empty.className = 'empty'; empty.textContent = `No ${id} yet.`; list.appendChild(empty); }
    for (const item of items) {
      const li = document.createElement('li'); li.className = item.status === 'done' ? 'done' : '';
      if (kind === 'task') { const check = document.createElement('input'); check.type = 'checkbox'; check.checked = item.status === 'done'; check.setAttribute('aria-label', `Complete ${item.title}`); check.onchange = async () => { check.disabled = true; try { await api('/assistant/tasks/' + item.id, { method: 'PATCH', body: JSON.stringify({ status: check.checked ? 'done' : 'open' }) }); await refreshState(); } catch (error) { setStatus(error.message); check.checked = !check.checked; check.disabled = false; } }; li.appendChild(check); }
      const text = document.createElement('span'); text.textContent = item.title || item.content; li.appendChild(text);
      const del = document.createElement('button'); del.type = 'button'; del.className = 'btn small danger'; del.textContent = 'Delete'; del.setAttribute('aria-label', `Delete ${kind}: ${item.title || item.content}`); del.onclick = async () => { if (!window.confirm(`Delete this ${kind}? This cannot be undone.`)) return; del.disabled = true; try { await api(`/assistant/${kind}s/${item.id}`, { method: 'DELETE' }); await refreshState(); } catch (error) { setStatus(error.message); del.disabled = false; } }; li.appendChild(del); list.appendChild(li);
    }
    if (kind === 'task') $('taskCount').textContent = items.filter(item => item.status === 'open').length;
  }
  function hideSavedLists() {
    savedListsHidden = true; savedViewVersion++;
    state.tasks = []; state.notes = [];
    for (const id of ['tasks', 'notes']) {
      const line = document.createElement('li'); line.className = 'empty'; line.textContent = 'Hidden on this page.';
      $(id).replaceChildren(line);
    }
    $('taskCount').textContent = '—';
    $('exportBtn').disabled = true;
    $('showSavedListsBtn').hidden = false;
  }
  async function refreshState() {
    const version = savedViewVersion, hidden = savedListsHidden;
    const data = await api('/assistant/state?' + (hidden ? 'metadata=1&' : '') + 'includeOmniRoute=1');
    // Hide/reveal can change while a request is in flight. Discard its response
    // rather than redisplay old data or replace a revealed list with metadata.
    if (version !== savedViewVersion || hidden !== savedListsHidden) return;
    if (hidden) { data.tasks = []; data.notes = []; }
    state = data;
    if (!savedListsHidden) {
      renderSavedList('tasks', state.tasks, 'task');
      renderSavedList('notes', state.notes, 'note');
      $('exportBtn').disabled = false;
      $('showSavedListsBtn').hidden = true;
    }
    const providers = state.cloudProviders || {};
    const options = Array.from($('provider').options);
    for (const option of options) {
      option.dataset.label ||= option.textContent;
      const value = providers[option.value];
      const configuredLabel = option.value === 'omniroute' ? ' · key & endpoint configured' : ' · key configured';
      option.textContent = option.dataset.label + (value === true ? configuredLabel : value === false ? ' · not configured' : ' · status unknown');
      option.disabled = value !== true && value !== false;
    }
    const selected = providers[$('provider').value];
    if ((!providerTouched && selected !== true) || (selected !== true && selected !== false)) {
      // Never select a provider that this page's HTML cannot display.
      const first = options.find(option => providers[option.value] === true) || options.find(option => providers[option.value] === false);
      $('provider').value = first?.value || '';
    }
    const values = options.map(option => providers[option.value]);
    const supportedCloud = values.includes(true) ? true : values.every(value => value === false) ? false : null;
    $('mode').querySelector('option[value="cloud"]').textContent = supportedCloud === true ? 'Cloud AI (provider configured; not live-tested)' : supportedCloud === false ? 'Cloud AI (not configured)' : 'Cloud AI (status unknown)';
    updateProviderStatus(); updateControls();
  }
  function updateProviderStatus() {
    const selected = $('provider').value;
    const value = state.cloudProviders?.[selected];
    const omni = selected === 'omniroute';
    let text = 'Provider configuration is unknown. Retry when settings are available or choose local tools.';
    if (value === true) text = omni
      ? 'OmniRoute has a server key and endpoint configured. Cloud text goes to that endpoint, which may forward it; charges may apply. A successful live request is still required.'
      : 'The selected provider has a server key. A successful live request is still required.';
    else if (value === false) text = omni
      ? 'OmniRoute needs both a server key and endpoint. Local tools work without them.'
      : 'No key is configured for the selected provider. Local tools work without a key.';
    $('cloudStatus').textContent = text;
  }
  function agentTrace(result) {
    // Renders the real tool trace: what ran, how long, and what it returned.
    const box = document.createElement('div');
    box.className = 'agent-trace';
    const head = document.createElement('div');
    head.className = 'agent-trace-head';
    head.textContent = `Agent trace · ${result.steps.length} step(s) · ${result.trace?.attempted ?? result.trace?.toolCalls ?? 0} attempted · ${result.trace?.toolCalls ?? 0} successful tool result(s) · ${result.trace?.failures ?? 0} failure(s) · ${result.trace?.totalMs ?? 0} ms`;
    box.appendChild(head);
    for (const step of result.steps) {
      const row = document.createElement('div');
      row.className = 'agent-step' + (step.ok ? '' : ' failed');
      const title = document.createElement('strong');
      title.textContent = `${step.ok ? '✓' : '✕'} ${step.title} · ${step.tool} · ${step.ms} ms`;
      const body = document.createElement('p');
      body.textContent = step.ok ? step.observation : `FAILED: ${step.observation}`;
      row.append(title, body);
      box.appendChild(row);
    }
    const note = document.createElement('p');
    note.className = 'hint';
    note.textContent = 'These are the only tools that ran. Writes (tasks, notes) still need your explicit confirmation.';
    box.appendChild(note);
    return box;
  }
  async function loadAgentTools() {
    try {
      const data = await api('/assistant/agent/tools');
      $('agentTools').textContent = 'Tools available: ' + data.tools.map(tool => tool.label).join(', ') + '. Every call is shown with its result.';
    } catch { $('agentTools').textContent = 'Tool list unavailable right now.'; }
  }
  async function runTool(result, signal) {
    const readTasks = result.tool === 'list_tasks' || result.tool === 'list_tasks_and_notes';
    const readNotes = result.tool === 'list_notes' || result.tool === 'list_tasks_and_notes';
    if (readTasks || readNotes) {
      // Fetch only what was explicitly requested, rather than speaking a stale
      // sidebar snapshot or reloading both categories after every message.
      if (result.taskStatus !== undefined && !['open', 'done'].includes(result.taskStatus)) throw new Error('The requested task filter was not understood. Try again.');
      const [tasksData, notesData] = await Promise.all([
        readTasks ? api('/assistant/tasks' + (result.taskStatus ? '?status=' + encodeURIComponent(result.taskStatus) : ''), { signal }) : null,
        readNotes ? api('/assistant/notes', { signal }) : null
      ]);
      if ((readTasks && !Array.isArray(tasksData?.tasks)) || (readNotes && !Array.isArray(notesData?.notes))) throw new Error('The requested saved items could not be read. Try again.');
      if (signal.aborted) return '';
      const parts = [];
      if (readTasks) {
        // A filtered reply must not silently replace the full list used by export.
        if (!savedListsHidden && !result.taskStatus) { state.tasks = tasksData.tasks; renderSavedList('tasks', state.tasks, 'task'); }
        const taskLabel = result.taskStatus === 'open' ? 'open tasks' : result.taskStatus === 'done' ? 'completed tasks' : 'tasks';
        parts.push(tasksData.tasks.length ? `Your ${taskLabel}:\n` + tasksData.tasks.map(t => `${t.status === 'done' ? '✓' : '○'} ${t.title}`).join('\n') : `No ${taskLabel} saved yet.`);
      }
      if (readNotes) {
        if (!savedListsHidden) { state.notes = notesData.notes; renderSavedList('notes', state.notes, 'note'); }
        parts.push(notesData.notes.length ? 'Your private notes:\n' + notesData.notes.map(n => '• ' + n.content).join('\n') : 'No notes saved yet.');
      }
      const output = parts.join('\n\n');
      addMessage(output, 'assistant', 'JalalAi · your requested saved items');
      return output;
    }
    if (result.tool === 'search_records') {
      const response = await api('/records?limit=200&q=' + encodeURIComponent(result.query), { signal });
      if (!Array.isArray(response.records)) throw new Error('Workspace records could not be read. Try again.');
      if (signal.aborted) return '';
      const output = response.records.length ? response.records.map(row => `• ${row.name || row.id}: ${row.notes || row.status || 'Record'}`).join('\n') : `No workspace records match “${result.query}”.`;
      addMessage(output, 'assistant', 'JalalAi · workspace search');
      return output;
    }
    return '';
  }
  async function send(text) {
    text = String(text || $('prompt').value).trim();
    if (!user) { setStatus('Please sign in first.'); return; }
    if (busy || !text) return;
    if (cloudStatusUnknown()) { setStatus('Provider configuration is unknown. Choose local tools or retry when settings are available.'); return; }
    stopVoice(); busy = true; $('prompt').value = ''; addMessage(text, 'user', 'You'); updateControls(); setStatus('Working… Stop cancels waiting for the reply.');
    const currentRequest = new AbortController(), requestSession = sessionVersion; requestController = currentRequest;
    let timedOut = false, replyShown = false;
    const timeout = setTimeout(() => { if (!currentRequest.signal.aborted) { timedOut = true; currentRequest.abort(); } }, 60000);
    try {
      const result = requireAssistantResponse(await api('/assistant/chat', { method: 'POST', signal: currentRequest.signal, body: JSON.stringify({ message: text, profile: $('profile').value, mode: $('mode').value, provider: $('provider').value, supportsCombinedReads: true, supportsTaskStatusFilter: true }) }));
      if (currentRequest.signal.aborted || requestSession !== sessionVersion) return;
      const label = result.cloudError ? 'JalalAi · local fallback (cloud unavailable)'
        : result.mode === 'agent' ? 'JalalAi · agent runtime (real tool trace)'
        : result.mode === 'cloud' ? `JalalAi · cloud ${result.provider}`
        : 'JalalAi · local tools / guidance';
      if (result.cloudError) setStatus(result.cloudError);
      else if (result.mode === 'agent') setStatus(result.trace?.failures ? `Agent finished with ${result.trace.failures} failed step(s) — see the trace.` : `Agent finished · ${result.trace?.toolCalls ?? 0} successful tool result(s) in ${result.trace?.totalMs ?? 0} ms.`);
      else setStatus(result.mode === 'cloud' ? 'Cloud reply received.' : 'Local tools completed the request.');
      if (result.readAccessBlocked) hideSavedLists();
      const localOutput = result.readAccessBlocked ? `${result.output}\n\nBoth sidebar lists are now hidden on this page. Choose “Show saved lists” to reload them; earlier chat may still contain saved items.` : result.output;
      // Keep the reason visible in the conversation, not only in the transient
      // status line, and do not present a local fallback as a Gemini reply.
      const output = result.cloudError ? `${result.cloudError}\n\nLocal response:\n${localOutput || 'No local response was returned.'}` : localOutput;
      const node = addMessage(output, 'assistant', label, result); replyShown = true;
      if (result.mode === 'agent' && Array.isArray(result.steps)) node.appendChild(agentTrace(result));
      const resolved = await runTool(result, currentRequest.signal);
      if (currentRequest.signal.aborted || requestSession !== sessionVersion) return;
      if ($('voiceReply').checked) speak(resolved || output);
    } catch (error) {
      if (requestSession !== sessionVersion) return;
      const cancelled = currentRequest.signal.aborted || error.name === 'AbortError';
      // Don't overwrite a new draft or repeat a prompt after a reply was shown.
      if (!replyShown && !$('prompt').value.trim()) $('prompt').value = text;
      const message = timedOut || error.name === 'TimeoutError'
        ? 'The request timed out. The server may still finish; check history or saved actions before retrying.'
        : cancelled ? 'Stopped waiting. The server may still finish; check history or saved actions before retrying.' : error.message;
      setStatus(message);
      if (!cancelled) addMessage(message, 'assistant error', 'Request could not complete');
    } finally {
      clearTimeout(timeout);
      if (requestController === currentRequest) { busy = false; requestController = null; updateControls(); }
    }
  }
  async function signIn() {
    const session = await api('/me'); csrf = session.csrfToken;
    if (!session.authenticated) {
      user = null; $('loginBanner').hidden = false; $('quickStart').hidden = false; $('sendBtn').disabled = true;
      const health = await api('/health'); $('demoBtn').hidden = !health.localPreview;
      $('loginMessage').textContent = health.localPreview ? 'Disposable preview: use test data only. Tasks and notes are account-scoped; workspace records are shared in this sandbox.' : 'Sign in with your account to use JalalAi and your private workspace.';
      $('connectionStatus').textContent = health.localPreview ? 'Local preview · not production' : 'Secure account required';
      setStatus(health.localPreview ? 'Choose “Try the local preview” to get started.' : 'Sign in to begin.'); updateControls(); return;
    }
    user = session.user; $('loginBanner').hidden = true; $('quickStart').hidden = true; await refreshState(); $('connectionStatus').textContent = 'Connected · ' + user.username; setStatus('Ready. Your microphone is off.'); updateControls();
  }
  // Hand-off from the share target and the protocol handler: the text the other
  // app sent is placed in the composer so the person reviews it before sending.
  // It is never sent automatically.
  function adoptHandoff() {
    let text = '';
    try { text = sessionStorage.getItem('aj-share-prompt-v1') || ''; sessionStorage.removeItem('aj-share-prompt-v1'); } catch { return; }
    if (!text) return;
    $('prompt').value = text.slice(0, 10000);
    updateControls();
    addMessage('Received from another app. It is in the composer so you can review or edit it before sending — nothing has been sent yet.', 'assistant', 'JalalAi · shared content');
    setStatus('Shared content is in your composer. Press Send when you are ready.');
  }
  $('chatForm').onsubmit = event => { event.preventDefault(); send(); };
  $('prompt').addEventListener('input', updateControls);
  $('prompt').addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); send(); } });
  document.querySelectorAll('[data-prompt]').forEach(button => button.onclick = () => send(button.dataset.prompt));
  $('mode').onchange = () => {
    const mode = $('mode').value;
    $('providerField').hidden = mode !== 'cloud';
    $('agentField').hidden = !['agent', 'research'].includes(mode);
    if (['agent', 'research'].includes(mode)) loadAgentTools();
    $('modeLabel').textContent = mode === 'cloud' ? 'Cloud AI · sends your message to the selected provider'
      : mode === 'agent' ? 'Agent runtime · bounded tool calls with a visible trace'
      : mode === 'research' ? 'Research · live Wikipedia search with cited links'
      : 'Local tools · no AI key required';
    updateControls();
  };
  $('provider').onchange = () => { providerTouched = true; updateProviderStatus(); updateControls(); };
  $('micBtn').onclick = () => {
    if (listening) { stopVoice(); setStatus('Microphone stopped.'); return; }
    const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Speech) { setStatus('Voice input is not supported in this browser. Type your message, or try a browser with Web Speech support.'); return; }
    stopVoice(); recognition = new Speech(); recognition.lang = $('speechLanguage').value || 'en-US'; recognition.interimResults = true; recognition.continuous = false;
    recognition.onstart = () => { listening = true; $('micBtn').textContent = '■ Stop mic'; $('micBtn').setAttribute('aria-pressed', 'true'); setStatus('Listening… press Stop mic to cancel. Your browser may use its speech service.'); updateControls(); };
    recognition.onresult = event => { const result = Array.from(event.results).map(r => r[0].transcript).join(' '); $('prompt').value = result; updateControls(); if (event.results[event.results.length - 1].isFinal) { stopVoice(); setStatus('Transcript ready. Review it, then press Send.'); } };
    recognition.onerror = event => { stopVoice(); setStatus(event.error === 'not-allowed' ? 'Microphone permission was denied. Allow it in browser settings or keep typing.' : `Voice input failed (${event.error}). You can still type.`); };
    recognition.onend = () => { listening = false; $('micBtn').textContent = '🎙 Speak'; $('micBtn').setAttribute('aria-pressed', 'false'); updateControls(); };
    try { recognition.start(); } catch { stopVoice(); setStatus('The microphone could not start. Try again or type your message.'); }
  };
  $('readBtn').onclick = () => speak(lastReply);
  $('stopBtn').onclick = () => { stopVoice(); if (requestController) { requestController.abort(); setStatus('Stopped waiting. The server may still finish; check history or saved actions before retrying.'); } else setStatus('Stopped.'); };
  $('clearChat').onclick = () => { if (busy || !window.confirm('Clear this chat? Saved tasks and notes are kept.')) return; stopVoice(); lastReply = ''; $('chatlog').replaceChildren(); addMessage('Chat cleared. Your saved tasks and notes are unchanged.', 'assistant', 'JalalAi · session reset'); };
  $('demoBtn').onclick = async () => { $('demoBtn').disabled = true; try { await api('/demo', { method: 'POST' }); await signIn(); } catch (error) { setStatus(error.message); } finally { $('demoBtn').disabled = false; } };
  $('accountBtn').onclick = async () => {
    if (!user) { location.href = 'index.html?next=jalalai.html'; return; }
    if (!window.confirm('Sign out of this device?')) return;
    try {
      await api('/auth/logout', { method: 'POST', body: '{}' });
      // A server response that was already in flight may contain saved items.
      // Abort it and invalidate its callbacks before clearing this session.
      sessionVersion++; requestController?.abort();
      user = null; csrf = ''; lastReply = ''; savedListsHidden = false; savedViewVersion++; state = { tasks: [], notes: [] };
      $('showSavedListsBtn').hidden = true; $('exportBtn').disabled = false; $('chatlog').replaceChildren();
      for (const id of ['tasks', 'notes']) $(id).replaceChildren();
      stopVoice(); await signIn();
    } catch (error) { setStatus(error.message); }
  };
  $('showSavedListsBtn').onclick = async () => {
    if (!user || busy) return;
    $('showSavedListsBtn').disabled = true; savedListsHidden = false; savedViewVersion++;
    try { await refreshState(); if (!savedListsHidden) setStatus('Saved lists loaded again.'); }
    catch (error) { hideSavedLists(); setStatus(error.message || 'Could not load the saved lists.'); }
    finally { updateControls(); }
  };
  $('exportBtn').onclick = () => { const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), tasks: state.tasks, notes: state.notes }, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob), anchor = document.createElement('a'); anchor.href = url; anchor.download = 'jalalai-private-export.json'; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); };
  function loadVoices() {
    if (!('speechSynthesis' in window)) return;
    // One shared catalogue + remembered choice across JalalAi, Workspace and Agent Studio.
    if (window.AJSpeech) { window.AJSpeech.populate($('voice')); window.AJSpeech.refresh(); return; }
    const voices = window.speechSynthesis.getVoices();
    $('voice').replaceChildren(new Option('System default', ''));
    for (const voice of voices) $('voice').add(new Option(`${voice.name} (${voice.lang})`, `${voice.name}|${voice.lang}`));
  }
  if ('speechSynthesis' in window) { loadVoices(); window.speechSynthesis.addEventListener('voiceschanged', loadVoices); }
  window.addEventListener('pagehide', () => { stopVoice(); requestController?.abort(); });
  if (window.AJ_STATIC_HOST) {
    $('loginBanner').hidden = false; $('quickStart').hidden = false; $('demoBtn').hidden = true; $('demoBtn').disabled = true; $('demoBtn').style.display = 'none'; $('sendBtn').disabled = true;
    $('loginMessage').textContent = 'Static website preview: JalalAi needs the secure application server for sign-in, tasks, notes and AI. Open the secure app, or run npm run dev locally. See Setup options in the banner.';
    $('connectionStatus').textContent = 'Static preview · backend not connected'; setStatus('Open the secure app or local preview to begin.'); updateControls();
  } else signIn().then(adoptHandoff).catch(error => {
    user = null; csrf = '';
    const missingDatabase = error.code === 'DATABASE_NOT_CONFIGURED';
    $('connectionStatus').textContent = missingDatabase ? 'Database not configured' : error.status ? 'Assistant unavailable' : 'Connection unavailable';
    setStatus(error.message);
    $('loginBanner').hidden = false; $('quickStart').hidden = true; $('demoBtn').hidden = true;
    $('loginMessage').textContent = missingDatabase
      ? 'This deployment’s database is not configured. The assistant cannot start here. Ask the site owner to configure it; no password was checked by this request.'
      : error.status ? 'The application responded, but the assistant could not start. Try again or contact the site owner.'
      : 'The server could not be reached. Check the connection and try again once the application is running.';
    updateControls();
  });
})();
