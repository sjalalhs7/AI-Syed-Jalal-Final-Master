import { builtInChecks, runChecks, searchSkills, verdictFor } from './self-check-core.mjs';
import { AGENT_TOOLS } from './agent-runtime.mjs';
import { providerConfiguration } from './provider-settings.mjs';
import { pageStatus } from './page-inventory.mjs';
import skillIndex from '../config/agent-skill-index.json';

// V133/V134 agent routes: shared skill library + account-scoped self-check evidence.
// The parent allows public static capabilities, authenticates other routes and
// checks CSRF on POST/PUT/PATCH/DELETE; POSTs here have per-user rate limits.
// Skill browsing is read-only; only Admins can explicitly synchronize the shared index.
const POLICY_VERSION = 'V150';

async function syncSkills(db) {
  const rows = skillIndex.skills.slice(0, 4000);
  // Single round trip: unnest + upsert. Keeps large catalogues fast on Neon.
  await db.query(
    `INSERT INTO agent_skills(id,name,domain,family,capability,objective)
     SELECT id,name,domain,family,capability,'' FROM unnest($1::text[],$2::text[],$3::text[],$4::text[],$5::text[]) AS t(id,name,domain,family,capability)
     ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name,domain=EXCLUDED.domain,family=EXCLUDED.family,capability=EXCLUDED.capability,updated_at=now()`,
    [rows.map(r => r[0]), rows.map(r => r[1]), rows.map(r => r[2]), rows.map(r => r[3]), rows.map(r => r[4])]
  );
  const count = await db.query('SELECT count(*)::int AS n FROM agent_skills');
  return Number(count[0]?.n || 0);
}

function cloudProviderState(env) {
  const providers = [
    { id: 'gemini', label: 'Google Gemini' },
    { id: 'openai', label: 'OpenAI' },
    { id: 'anthropic', label: 'Anthropic Claude' },
    { id: 'deepseek', label: 'DeepSeek' }
  ];
  return providers.map(provider => {
    const configured = providerConfiguration(env, provider.id);
    return {
      id: provider.id,
      label: provider.label,
      configured,
      status: configured === true ? 'Key configured; a live call is still required before claiming it works'
        : configured === false ? 'API key not configured' : 'Stored settings could not be read; configuration is unknown'
    };
  });
}

export async function agentRoute({ request, env, db, me, url, readBody, reply, audit, consumeRateLimit, onRequest }) {
  const path = url.pathname, method = request.method;
  if (!path.startsWith('/api/agent/')) return null;

  if (path === '/api/agent/skills' && method === 'GET') {
    const q = String(url.searchParams.get('q') || '').slice(0, 120);
    const domain = String(url.searchParams.get('domain') || '').slice(0, 120);
    const limit = Math.min(50, Math.max(1, Number(url.searchParams.get('limit') || 20)));
    try {
      // Browsing must remain a read-only GET. An Admin may explicitly run the
      // CSRF-protected sync POST when the shared catalogue needs refreshing.
      await db.query('SELECT count(*)::int AS n FROM agent_skills');
    } catch (error) {
      // A missing migration must not silently look like an empty catalogue.
      if (!/agent_skills/.test(String(error?.message || ''))) throw error;
      return reply({ ok: false, error: 'Skill storage is not migrated. Apply backend/db/migrations/009_v133_agent_skills.sql.', code: 'SKILLS_NOT_MIGRATED' }, 503);
    }
    let skills, total;
    if (q) {
      skills = searchSkills(q, skillIndex, limit);
      total = skills.length;
    } else {
      const count = await db.query('SELECT count(*)::int AS n FROM agent_skills');
      total = Number(count[0]?.n || 0);
      if (total === 0) {
        // An empty shared table is still browseable without turning GET into a
        // write. The bundled index is the read-only fallback until Admin sync.
        const available = skillIndex.skills.filter(row => !domain || row[2] === domain);
        total = available.length;
        skills = available.slice(0, limit).map(([id, name, itemDomain, family, capability]) => ({ id, name, domain: itemDomain, family, capability }));
      } else {
        const rows = await db.query(
          "SELECT id,name,domain,family,capability FROM agent_skills WHERE ($2='' OR domain=$2) ORDER BY domain,name LIMIT $1",
          [limit, domain]
        );
        skills = rows.map(row => ({ id: row.id, name: row.name, domain: row.domain, family: row.family, capability: row.capability }));
      }
    }
    const domainRows = await db.query('SELECT domain,count(*)::int AS n FROM agent_skills GROUP BY domain ORDER BY domain');
    const domains = domainRows.length ? domainRows.map(row => ({ name: row.domain, count: Number(row.n) })) : skillIndex.domains.map(row => ({ name: row.name, count: Number(row.skillCount) }));
    return reply({ ok: true, version: POLICY_VERSION, query: q || null, domain: domain || null, total, returned: skills.length, domains, skills });
  }

  if (path === '/api/agent/skills' && method === 'POST') {
    if (me.role !== 'Admin') return reply({ error: 'Admin role required to sync the shared skill catalogue.' }, 403);
    if (!await consumeRateLimit(db, 'agent-sync', me.id, 4, 300)) return reply({ error: 'Skill sync is limited to a few runs every five minutes.' }, 429, { 'Retry-After': '300' });
    const count = await syncSkills(db);
    await audit(db, me, 'AGENT_SKILLS_SYNC', `Skill library synced (${count} skills)`, request);
    return reply({ ok: true, count, domains: skillIndex.domainCount, version: POLICY_VERSION });
  }

  if (path === '/api/agent/self-check' && method === 'GET') {
    const rows = await db.query('SELECT id,engine,provider,checks_total AS "checksTotal",checks_passed AS "checksPassed",score,verdict,created_at AS "createdAt" FROM agent_self_checks WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20', [me.id]);
    const latest = rows[0] || null;
    return reply({ ok: true, version: POLICY_VERSION, latest, history: rows, providers: cloudProviderState(env), engine: 'SJ Self-Check Engine', scope: 'Deterministic verification of this deployment: API, database, security boundaries, agent behaviour, honesty labels, skill catalogue and page inventory. It is evidence, not a production certificate.' });
  }

  if (path === '/api/agent/self-check' && method === 'POST') {
    if (!await consumeRateLimit(db, 'agent-selfcheck', me.id, 6, 60)) return reply({ error: 'Self-check is limited to six runs per minute.' }, 429, { 'Retry-After': '60' });
    const body = await readBody(request);
    const engine = body.engine === 'cloud' ? 'cloud' : 'local';
    const provider = engine === 'cloud' ? String(body.provider || 'gemini').slice(0, 40) : 'local';
    const providerState = cloudProviderState(env).find(item => item.id === provider);
    if (engine === 'cloud' && !providerState) {
      return reply({ ok: false, code: 'UNSUPPORTED_PROVIDER', error: 'Choose a supported cloud provider. No request was made to the provider.' }, 400);
    }
    if (engine === 'cloud' && providerState.configured !== true) {
      const unknown = providerState.configured === null;
      return reply({
        ok: false,
        code: unknown ? 'PROVIDER_STATUS_UNKNOWN' : 'PROVIDER_NOT_CONFIGURED',
        error: unknown
          ? `${providerState.label} configuration is unknown because stored settings could not be read. No request was made to the provider. Use the local engine or retry when settings are available.`
          : `${providerState.label} is not configured, so the cloud self-check cannot run. No request was made to the provider. Use the local engine or configure the key server-side.`,
        localResult: null,
        providers: cloudProviderState(env)
      }, unknown ? 503 : 400);
    }
    const only = Array.isArray(body.only) ? body.only.map(String).slice(0, 30) : undefined;
    const timeoutMs = Math.min(10000, Math.max(500, Number(body.timeoutMs) || 4000));
    const checks = builtInChecks();
    // Self-checks do not synchronize shared catalogue rows. If an Admin needs
    // to refresh that read model, use the explicit, rate-limited sync action.
    const pages = await pageStatus(env);
    const outcome = await runChecks(checks, {
      db, me, env, request, onRequest, pages, index: skillIndex, searchSkills,
      now: new Date()
    }, { only, timeoutMs });

    // Engine comparison: same checks, different runner label.

    let comparison = null;
    if (engine === 'cloud') {
      const second = await runChecks(checks, { db, me, env, request, onRequest, pages, index: skillIndex, searchSkills, now: new Date() }, { only, timeoutMs });
      comparison = { localScore: outcome.score, cloudScore: second.score, delta: second.score - outcome.score, note: 'Both passes execute the same deterministic checks. A cloud engine adds a provider label, not extra truth: a configured key is still not a verified live model answer.' };
      outcome.score = Math.round((outcome.score + second.score) / 2);
      outcome.verdict = verdictFor([...outcome.results, ...second.results]);
    }

    await db.query(
      'INSERT INTO agent_self_checks(id,user_id,engine,provider,checks_total,checks_passed,score,verdict,details) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb)',
      [crypto.randomUUID(), me.id, engine, provider, outcome.checksTotal, outcome.checksPassed, outcome.score, outcome.verdict, JSON.stringify(outcome.results)]
    );
    await audit(db, me, 'AGENT_SELF_CHECK', `${engine}/${provider} score=${outcome.score} verdict=${outcome.verdict}`, request);
    return reply({ ok: true, version: POLICY_VERSION, engine, provider, providers: cloudProviderState(env), comparison, ...outcome });
  }

  if (path === '/api/agent/capabilities' && method === 'GET') {
    return reply({
      ok: true,
      version: POLICY_VERSION,
      profiles: [
        { id: 'general', label: 'General assistant', summary: 'Greeting, help, calculation routing and honesty about unconfigured providers.' },
        { id: 'planner', label: 'Planner', summary: 'Converts a goal into a numbered, executable plan with a disclaimer.' },
        { id: 'critic', label: 'Critic', summary: 'Challenges evidence, security, reliability, usability and operations.' },
        { id: 'coding', label: 'Coding advisor', summary: 'Contract → smallest change → validation → tests → review.' },
        { id: 'analysis', label: 'Analysis advisor', summary: 'Structured analysis without pretending to be an external model.' }
      ],
      providers: cloudProviderState(env),
      selfCheck: { checks: builtInChecks().map(check => ({ id: check.id, title: check.title, group: check.group, weight: check.weight, severity: check.severity })), path: '/api/agent/self-check' },
      skills: { count: skillIndex.count, domains: skillIndex.domainCount, path: '/api/agent/skills' },
      // V140: the toolbox is published so Toolbench, Agent Studio and the tests
      // all read one list instead of three copies that can drift.
      tools: AGENT_TOOLS.map(tool => ({ ...tool })),
      toolbox: { count: AGENT_TOOLS.length, path: '/api/agent/run', page: 'toolbench.html' },
      limits: { timeoutMs: 4000, maxChecksPerRun: builtInChecks().length }
    });
  }

  if (path === '/api/agent/report' && method === 'GET') {
    const historical = await db.query('SELECT score,verdict,created_at AS "createdAt" FROM agent_self_checks WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50', [me.id]);
    const trend = historical.map(row => ({ score: Number(row.score), verdict: row.verdict, createdAt: row.createdAt })).reverse();
    const latest = historical[0] || null;
    return reply({
      ok: true,
      version: POLICY_VERSION,
      generatedAt: new Date().toISOString(),
      account: { username: me.username, role: me.role },
      latest: latest ? { score: Number(latest.score), verdict: latest.verdict, createdAt: latest.createdAt } : null,
      trend,
      disclaimer: 'Self-check evidence reflects this deployment at run time. It does not certify live provider calls, physical devices, legal/medical compliance or production load.'
    });
  }

  return reply({ ok: false, error: 'Agent route not found.', code: 'AGENT_ROUTE_NOT_FOUND' }, 404);
}
