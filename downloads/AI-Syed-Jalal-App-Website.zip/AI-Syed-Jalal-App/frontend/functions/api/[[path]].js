import { neon } from '@neondatabase/serverless';
import { scrypt } from 'scrypt-js';
import { localAssistant } from '../assistant-core.mjs';
import { assistantRoute } from '../assistant-routes.mjs';
import { platformRoute } from '../platform-routes.mjs';
import { agentRoute } from '../agent-routes.mjs';
import { contentReportRoute } from '../content-report-routes.mjs';
import { arenaRoute, arenaCatalogue } from '../arena-routes.mjs';
import libraryCatalog from '../../config/library-catalog.json';
import { SCHEMA_PARTS, REQUIRED_TABLES, destructiveStatements } from '../schema-bundle.mjs';
import { applySchemaRepair, missingTables, schemaRepairEnabled } from '../schema-repair.mjs';
import { effectiveEnv, providerStates, updateStoredProviderKey, maskKey, PROVIDER_IDS, providerConfiguration, aggregateProviderConfiguration, unavailableProviderEnv } from '../provider-settings.mjs';
import { normalizeRecords, normalizeRecordPatch, MAX_BATCH_RECORDS } from '../../assets/records-transfer.js';

const C = 'aj_session', TTL = 28800000, WRITERS = ['Admin','Manager','Data Operator'];
const reply = (data,status=200,headers={}) => Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Permissions-Policy':'camera=(), microphone=(self), geolocation=()','Cross-Origin-Opener-Policy':'same-origin',...headers}});
const hex = b => Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
const random = n => crypto.getRandomValues(new Uint8Array(n));
const digest = async s => hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))));
const pass = async (p,s) => hex(await scrypt(new TextEncoder().encode(String(p)),new TextEncoder().encode(String(s)),16384,8,1,64));
const equal = (a,b) => {const x=new TextEncoder().encode(String(a)),y=new TextEncoder().encode(String(b));if(x.length!==y.length)return false;let d=0;for(let i=0;i<x.length;i++)d|=x[i]^y[i];return d===0};
// First-admin setup is an owner-controlled recovery operation, not public
// registration. It is closed unless an operator explicitly enables it AND
// supplies a strong seed. Existing-admin seed-password recovery is separate.
function configuredSeedAdmin(env){
 const username=String(env.SEED_ADMIN_USERNAME||''),password=String(env.SEED_ADMIN_PASSWORD||'');
 if(!/^[A-Za-z0-9_.-]{3,40}$/.test(username)||password.length<12||password.length>1024||!/[A-Za-z]/.test(password)||!/[0-9]/.test(password)||/change-?me|replace/i.test(password))return null;
 return {username,password};
}
function configuredInitialSetup(env){
 return env.FIRST_ADMIN_SETUP_ENABLED==='true'?configuredSeedAdmin(env):null;
}
const cookies = r => Object.fromEntries((r.headers.get('cookie')||'').split(';').map(x=>x.trim()).filter(Boolean).map(x=>{const i=x.indexOf('=');if(i<0)return [x,''];const k=x.slice(0,i),v=x.slice(i+1);try{return [k,decodeURIComponent(v)]}catch{return [k,v]}}));
const rawToken = r => {const a=r.headers.get('authorization')||'';return a.startsWith('Bearer ')?a.slice(7):(cookies(r)[C]||'')};
const csrf = async (t,s) => {if(!s||s.length<32)throw Error('CSRF_SECRET is not configured');const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(s),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(new Uint8Array(await crypto.subtle.sign('HMAC',k,new TextEncoder().encode(t))))};
const readBody = async (r,max=1024*1024) => {const declared=Number(r.headers.get('content-length')||0);if(declared>max)throw Object.assign(Error('Request body too large'),{status:413});if(!r.body)return {};const reader=r.body.getReader(),chunks=[];let size=0;try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>max){await reader.cancel();throw Object.assign(Error('Request body too large'),{status:413})}chunks.push(value)}}finally{reader.releaseLock()}const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength}const t=new TextDecoder().decode(bytes);if(!t)return {};try{const value=JSON.parse(t);if(!value||typeof value!=='object'||Array.isArray(value))throw Error();return value}catch{throw Object.assign(Error('Invalid JSON body'),{status:400})}};
const sessionCookie = (t,env={}) => C+'='+t+'; Max-Age=28800; Path=/; HttpOnly;'+((env.DB_ADAPTER&&env.COOKIE_SECURE==='false')?'':' Secure;')+' SameSite=Lax';
// Requiring JSON prevents cross-site HTML forms from silently creating or
// replacing a browser session. The API does not grant cross-origin CORS access.
const isAuthJson = req => /^application\/json(?:\s*;|$)/i.test((req.headers.get('content-type')||'').trim());
const hasCsrfSecret = env => String(env.CSRF_SECRET||env.SESSION_SECRET||'').length>=32;
const usernameExists = async (db,name) => (await db.query('SELECT id FROM app_users WHERE lower(username)=lower($1) LIMIT 1',[name])).length>0;
async function audit(db,u,action,detail,req){try{await db.query('INSERT INTO audit_events(id,user_id,action,detail,ip,request_id) VALUES($1,$2,$3,$4,$5,$6)',[crypto.randomUUID(),u?u.id:null,action,detail,req.headers.get('CF-Connecting-IP')||'',req.headers.get('cf-ray')||null])}catch{}}
async function consumeRateLimit(db, scope, subject, capacity, refillSeconds){
 const subjectHash=await digest(subject),requestId=crypto.randomUUID();
 const rows=await db.query(`WITH stale AS (DELETE FROM auth_rate_limits WHERE updated_at<now()-interval '30 days' AND NOT (scope=$1 AND subject_hash=$2) RETURNING 1), applied AS (INSERT INTO auth_rate_limits(scope,subject_hash,tokens,updated_at,last_request_id) SELECT $1,$2,$3::numeric-1,now(),$5 FROM (SELECT count(*) FROM stale) cleanup ON CONFLICT(scope,subject_hash) DO UPDATE SET tokens=CASE WHEN auth_rate_limits.tokens+GREATEST(0,EXTRACT(EPOCH FROM (now()-auth_rate_limits.updated_at))/$4::numeric)>=1 THEN LEAST($3::numeric,auth_rate_limits.tokens+GREATEST(0,EXTRACT(EPOCH FROM (now()-auth_rate_limits.updated_at))/$4::numeric))-1 ELSE auth_rate_limits.tokens END,updated_at=CASE WHEN auth_rate_limits.tokens+GREATEST(0,EXTRACT(EPOCH FROM (now()-auth_rate_limits.updated_at))/$4::numeric)>=1 THEN now() ELSE auth_rate_limits.updated_at END,last_request_id=CASE WHEN auth_rate_limits.tokens+GREATEST(0,EXTRACT(EPOCH FROM (now()-auth_rate_limits.updated_at))/$4::numeric)>=1 THEN $5 ELSE auth_rate_limits.last_request_id END RETURNING last_request_id=$5 AS allowed) SELECT allowed FROM applied`,[scope,subjectHash,capacity,refillSeconds,requestId]);
 return rows[0]?.allowed===true;
}
async function userFor(db,req){const t=rawToken(req);if(!t)return null;const a=await db.query('SELECT u.id,u.username,u.role,s.id AS session_id FROM sessions s JOIN app_users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now() AND u.active=true LIMIT 1',[await digest(t)]);return a[0]||null}
async function validCsrf(req,env){const t=rawToken(req),v=req.headers.get('x-csrf-token')||'';return !!(t&&v&&equal(await csrf(t,env.CSRF_SECRET||env.SESSION_SECRET||''),v))}
// Configuration is tri-state: a failed settings read is not proof of absence.
// Neither key presence nor a configured endpoint verifies provider connectivity.
function aiProviderCapabilities(env) {
 const providers=[
  {id:'openai',label:'OpenAI / ChatGPT',model:env.OPENAI_MODEL||'gpt-4o-mini'},
  {id:'anthropic',label:'Anthropic / Claude',model:env.ANTHROPIC_MODEL||'claude-3-5-haiku-latest'},
  {id:'deepseek',label:'DeepSeek',model:env.DEEPSEEK_MODEL||'deepseek-chat'},
  {id:'gemini',label:'Google Gemini',model:env.GEMINI_MODEL||'gemini-2.5-flash'},
  {id:'omniroute',label:'OmniRoute (OpenAI-compatible)',model:env.OMNIROUTE_MODEL||'provider default'}
 ];
 return providers.map(provider=>{
  const configured=providerConfiguration(env,provider.id);
  const status=configured===true?(provider.id==='omniroute'?'Key and endpoint configured; live call not yet verified':'Key configured; live call not yet verified')
   :configured===false?(provider.id==='omniroute'?'Optional key/base URL not configured':'API key not configured')
   :'Stored settings could not be read; configuration is unknown';
  return {...provider,configured,status,adapter:'enabled'};
 });
}
function providerMode(providers){
 const configured=aggregateProviderConfiguration(providers.map(provider=>provider.configured));
 return configured===true?'live-ready':configured===false?'provider-keys-required':'provider-status-unknown';
}

export async function onRequest(ctx){
 const request=ctx.request;
 const u=new URL(request.url),p=u.pathname.split('/').filter(Boolean);
 const baseEnv=ctx.env;
 // Layer Admin-set keys from app_settings over the deployment environment so a
 // key added in the Operations panel works immediately, with no redeploy.
 let env=baseEnv;
 try{
   if(baseEnv.DATABASE_URL||baseEnv.DB_ADAPTER){
     const probe=baseEnv.DB_ADAPTER||neon(baseEnv.DATABASE_URL);
     env=await effectiveEnv(baseEnv,probe);
   }
 }catch{ env=unavailableProviderEnv(baseEnv) }
 if(!u.pathname.startsWith('/api/'))return reply({ok:false,error:'Not found'},404);
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{Allow:'GET,POST,PUT,PATCH,DELETE,OPTIONS','Cache-Control':'no-store'}});
 if(!env.DB_ADAPTER&&!env.DATABASE_URL)return reply({ok:false,error:'Neon DATABASE_URL is not configured',code:'DATABASE_NOT_CONFIGURED'},503);
 const db=env.DB_ADAPTER||neon(env.DATABASE_URL);
 try{
  if(u.pathname==='/api/health'&&request.method==='GET'){await db.query('SELECT 1');return reply({ok:true,service:'Al-Syed Jalal AI Cloudflare API',version:'V150',runtime:env.LOCAL_PREVIEW?'Local preview':'Cloudflare Pages Functions',database:env.LOCAL_PREVIEW?'PGlite (local PostgreSQL)':'Neon PostgreSQL',localPreview:Boolean(env.LOCAL_PREVIEW),assistant:{localTools:true,voiceInput:'browser-dependent',voiceOutput:'browser-speech',cloudConfigured:aggregateProviderConfiguration(['gemini','openai','anthropic','deepseek','omniroute'].map(id=>providerConfiguration(env,id)))},databaseConnected:true})}
  if(u.pathname==='/api/chat'&&request.method==='POST'){const target=new URL(request.url);target.pathname='/api/ai/run';const response=await onRequest({request:new Request(target,request),env});if(!response.ok)return response;const result=await response.json();return reply({...result,reply:result.output||''},response.status)}
  if(u.pathname==='/api/demo'&&request.method==='POST'){if(!env.LOCAL_PREVIEW||!env.DB_ADAPTER)return reply({error:'Not found'},404);if(await userFor(db,request))return reply({ok:true,preview:true});if(!await consumeRateLimit(db,'preview-session',request.headers.get('CF-Connecting-IP')||'local',Math.max(1,Number(env.PREVIEW_SESSION_PER_MINUTE)||10),60))return reply({error:'Please wait before starting another preview account.'},429);const id=crypto.randomUUID(),token=hex(random(48)),salt=hex(random(16));await db.query("INSERT INTO app_users(id,username,role,salt,password_hash) VALUES($1,$2,'Admin',$3,$4)",[id,'preview-'+id.slice(0,8),salt,await pass(hex(random(24)),salt)]);await db.query('INSERT INTO sessions(id,user_id,token_hash,expires_at) VALUES($1,$2,$3,$4)',[crypto.randomUUID(),id,await digest(token),new Date(Date.now()+TTL).toISOString()]);return reply({ok:true,preview:true},200,{'Set-Cookie':sessionCookie(token,env)})}
  if(u.pathname==='/api/version'&&request.method==='GET')return reply({app:'Al-Syed Jalal AI',version:'V150',release:'cloudflare-native'});
  if(u.pathname==='/api/ready'&&request.method==='GET'){
   await db.query('SELECT 1');
   const rows=await db.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public'");
   const have=(rows||[]).map(r=>r.table_name);
   const n=REQUIRED_TABLES.filter(t=>have.includes(t)).length;
   const missing=REQUIRED_TABLES.filter(t=>!have.includes(t));
   const ok=missing.length===0;
   const affected=missing.length?'Some features, including Arena, Agent Lab, the Expert Critic and content reports, may fail until their required tables exist.':'Nothing is missing.';
   // Only an authenticated Admin sees the repair lock state. Session lookup
   // failure must not make the public readiness endpoint unavailable.
   const viewer=await userFor(db,request).catch(()=>null);
   const repair=viewer?.role==='Admin'?{schemaRepairEnabled:schemaRepairEnabled(env)}:{};
   return reply({ok,ready:ok,database:env.LOCAL_PREVIEW?'PGlite (local PostgreSQL)':'Neon PostgreSQL',schemaTables:n,required:REQUIRED_TABLES.length,missing,summary:`${n} of ${REQUIRED_TABLES.length} tables present. ${affected}`,howToFix:'Verify a restorable full database backup and rehearse on an isolated target. The repair path is locked by default and also requires operator authorization.',scope:'required table names only; columns, indexes, migration history, data and provider behavior are not checked',signInAffected:!(['app_users','sessions'].every(t=>have.includes(t))),...repair},ok?200:503)
  }
  if(u.pathname==='/api/ai/capabilities'&&request.method==='GET'){const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);const providers=aiProviderCapabilities(env);const agents=[{id:'general',name:'General Assistant',group:'General',mode:'provider-backed text profile'},{id:'coding',name:'Coding Assistant',group:'Development',mode:'provider-backed text profile'},{id:'ux-ui-pro-max',name:'UX/UI Design Assistant',group:'Design',mode:'provider-backed text profile'},{id:'analysis',name:'Analysis Assistant',group:'Analysis',mode:'provider-backed text profile'},{id:'superpower',name:'Task Planning Assistant',group:'Planning',mode:'bounded text planning; no external tools'}];return reply({mode:providerMode(providers),agents,executableAgentProfiles:agents.length,catalogRoles:120,agencyLayer:{profiles:303,execution:'profiles/catalog available in recovered backend; Cloudflare text endpoint does not execute every profile as a separate tool'},skillRegistry:{version:'V71.0.0',totalSkills:3500,domainCount:35,source:'recovered project config/ai-skill-index-v71.json'},skills:[],skillPacks:[],providers,status:'This API exposes five provider-backed text prompt profiles. They do not browse the web, query private records, use voice or medical tools, or execute external actions. The separate catalogue contains 120 role definitions and 3,500 reference skills across 35 domains; catalogue entries are not independent model instances. A configured provider key does not prove a successful live request.',runtime:{providers:Object.fromEntries(providers.map(p=>[p.id,{configured:p.configured,adapter:p.adapter}]))}})}
  // --- V149 admin-managed provider keys ----------------------------------------
  if(u.pathname==='/api/admin/providers'&&request.method==='GET'){
   const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   const states=await providerStates(baseEnv,db);
   return reply({providers:states,note:'A configured key is not proof the provider accepts it. Send a prompt to find out. Keys are never returned in full.'});
  }

  if(u.pathname==='/api/admin/providers'&&request.method==='POST'){
   const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   // This route precedes the shared mutation guard below, so enforce CSRF here.
   if(!await validCsrf(request,env))return reply({error:'CSRF protection: missing or invalid X-CSRF-Token'},403);
   if(!await consumeRateLimit(db,'provider-keys',me.id,10,600))return reply({error:'Too many key changes. Wait ten minutes.'},429);
   const x=await readBody(request);
   const provider=String(x.provider||'').toLowerCase();
   if(!PROVIDER_IDS.includes(provider))return reply({error:'Unknown provider. Choose one of: '+PROVIDER_IDS.join(', ')},400);
   const removing=x.remove===true;
   const key=removing?null:String(x.key||'').trim();
   if(!removing&&(!key||key.length<8||key.length>400))return reply({error:'That does not look like an API key (expected 8-400 characters).'},400);
   if(!removing&&/\s/.test(key))return reply({error:'API keys do not contain spaces. Check for a stray paste.'},400);
   let saved;
   try{saved=await updateStoredProviderKey(db,provider,key,me.username)}
   catch{return reply({code:'PROVIDER_SETTINGS_WRITE_UNCONFIRMED',error:'The provider-key change could not be confirmed. Refresh the provider status and ask an administrator to investigate before retrying.'},503)}
   if(!saved)return reply({code:'PROVIDER_SETTINGS_INVALID',error:'The saved provider settings have an unexpected format. No change was made; ask an administrator to investigate.'},409);
   await audit(db,me,'PROVIDER_KEY_'+(removing?'REMOVED':'SET'),provider,request);
   return reply({ok:true,providers:await providerStates(baseEnv,db),note:'Saved. Send a prompt to verify the provider actually answers.'});
  }

  if(u.pathname==='/api/admin/ai/overview'&&request.method==='GET'){const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);if(me.role!=='Admin')return reply({error:'Admin role required'},403);const rows=await db.query("SELECT count(*)::int AS runs,count(*) FILTER (WHERE status='completed')::int AS completed,count(*) FILTER (WHERE status<>'completed')::int AS non_completed,0::int AS tokens FROM ai_runs WHERE created_at>now()-interval '24 hours'");const x=rows[0]||{};return reply({summary:{runs:Number(x.runs||0),completed:Number(x.completed||0),non_completed:Number(x.non_completed||0),tokens:Number(x.tokens||0)}})}
  if(u.pathname==='/api/admin/ai/provider-health'&&request.method==='GET'){const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);if(me.role!=='Admin')return reply({error:'Admin role required'},403);const providers=aiProviderCapabilities(env);return reply({providers,mode:providerMode(providers)==='provider-keys-required'?'demo':providerMode(providers),note:'Key presence is not proof of successful provider authentication; run a test prompt to verify.'})}
  if(u.pathname==='/api/library'&&request.method==='GET'){const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);return reply({version:libraryCatalog.version,skillRegistry:{name:libraryCatalog.name,version:libraryCatalog.version,totalSkills:libraryCatalog.count,domainCount:libraryCatalog.domain_count},skills:libraryCatalog.skills,domains:libraryCatalog.domains,superpowers_skills:libraryCatalog.superpowers_skills,templates:libraryCatalog.templates,sources:libraryCatalog.sources})}
  // Admin-only schema repair. Missing table names indicate an incomplete schema,
  // not why it happened. Verify a full backup, rehearse on an isolated target,
  // and obtain explicit approval; a partial run may have committed work.
  if(u.pathname==='/api/admin/schema/repair'&&request.method==='POST'){
   const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   // This route precedes the shared mutation guard below, so enforce CSRF here.
   if(!await validCsrf(request,env))return reply({error:'CSRF protection: missing or invalid X-CSRF-Token'},403);
   const x=await readBody(request);
   const missingBefore=await missingTables(db);
   if(!missingBefore.length)return reply({ok:true,changed:false,message:'All required table names are present; no migrations were run. Columns, indexes and migration history were not checked.',tables:REQUIRED_TABLES.length,required:REQUIRED_TABLES.length});
   if(x.confirm!=='apply-schema-repair')return reply({error:'No migrations were run. After verifying a restorable full database backup, rehearsing on an isolated target, and obtaining authorization, send {"confirm":"apply-schema-repair"}.',preview:{missing:missingBefore,parts:SCHEMA_PARTS.length,transactional:false,warning:'Statements run individually; a failed repair can leave partial changes.'}},400);
   // Fail closed before the rate-limit write or any migration. Unlocking is an
   // operator decision, not evidence that the backup or rehearsal succeeded.
   if(!schemaRepairEnabled(env))return reply({code:'SCHEMA_REPAIR_LOCKED',started:false,error:'Repair is locked by server configuration. No migrations were run. Verify a restorable full backup, rehearse on an isolated target and obtain authorization before an operator unlocks this path.'},423);
   if(!await consumeRateLimit(db,'schema-repair',me.id,5,600))return reply({error:'Too many repair attempts. Wait ten minutes.'},429);
   const result=await applySchemaRepair(db);
   if(result.refused)return reply({error:result.error,unsafe:result.unsafe},500);
   await audit(db,me,'SCHEMA_REPAIR',`applied ${result.applied.length} parts; ${result.missing.length} tables still missing`,request);
   return reply({ok:result.ok,changed:result.changed,before:result.before,after:result.after,required:result.required,applied:result.applied,failed:result.failed,missing:result.missing},result.ok?200:207);
  }
  if(u.pathname==='/api/admin/diagnostics'&&request.method==='GET'){
  const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   const missing=await missingTables(db),missingSet=new Set(missing);
   const tables=REQUIRED_TABLES.filter(name=>!missingSet.has(name)),schemaOk=missing.length===0;
   const active=tables.includes('sessions')?await db.query('SELECT count(*)::int AS n FROM sessions WHERE revoked_at IS NULL AND expires_at>now()'):[];
   const ai=tables.includes('ai_runs')?await db.query("SELECT count(*)::int AS n FROM ai_runs WHERE status='running' AND created_at>now()-interval '10 minutes'"):[];
   return reply({ok:schemaOk,status:schemaOk?'healthy':'schema-incomplete',database:env.LOCAL_PREVIEW?'PGlite (local PostgreSQL)':'Neon PostgreSQL',checks:{database:true,schema:schemaOk,aiRuntime:true},schemaTables:tables.length,required:REQUIRED_TABLES.length,missing,tables,pool:{available:false,total:null,waiting:null},ai:{active:ai.length?Number(ai[0].n):null,maxConcurrent:null},sessions:{active:active.length?Number(active[0].n):null},note:'Schema checks required table names only, not columns, indexes, migration history or live features. Pool and edge process metrics are not exposed. AI runtime refers to the local assistant, not a live-tested cloud provider.'});
  }
  if(u.pathname==='/api/admin/audit'&&request.method==='GET'){const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);if(me.role!=='Admin')return reply({error:'Admin role required'},403);const limit=Math.min(100,Math.max(1,Number(u.searchParams.get('limit')||20)));const rows=await db.query('SELECT e.id,e.action,e.detail,e.created_at,u.username FROM audit_events e LEFT JOIN app_users u ON u.id=e.user_id ORDER BY e.created_at DESC LIMIT $1',[limit]);return reply({events:rows.map(x=>({id:x.id,time:x.created_at,user:x.username||'system',action:x.action,detail:x.detail||''}))})}
  // First-admin setup requires explicit operator enablement and the configured
  // seed. Even an inactive Admin blocks it. This is not a permanent one-time
  // database seal or a global atomic one-admin constraint. Existing accounts
  // must also prove their own password; recovery requires operator review.
  if(u.pathname==='/api/bootstrap/status'&&request.method==='GET'){
   try{
     const admins=Number((await db.query("SELECT count(*)::int AS n FROM app_users WHERE role='Admin' AND active=true"))[0]?.n||0);
     const allAdmins=Number((await db.query("SELECT count(*)::int AS n FROM app_users WHERE role='Admin'"))[0]?.n||0);
     let users=0;
     try{const u=await db.query('SELECT count(*)::int AS n FROM app_users');users=Number(u[0]?.n||0)}catch{}
     const open=allAdmins===0&&Boolean(configuredInitialSetup(env));
     const reason=allAdmins>0?'An Administrator account already exists. Contact the deployment owner if it is inactive.':open?'No Administrator account exists. The deployment owner can use the configured seed account to set one up.':'Administrator setup is disabled. Contact the deployment owner for an authorized recovery procedure.';
     return reply({available:open,users,admins,completed:allAdmins>0,reason});
   }catch(e){
     // app_users itself may be missing on a database that was never migrated.
     return reply({available:false,users:0,admins:0,completed:false,reason:'The database is not initialised yet: '+(e?.message||e)});
   }
  }

  if(u.pathname==='/api/bootstrap/admin'&&request.method==='POST'){
   if(!isAuthJson(request))return reply({error:'Use a JSON request.'},415);
   if(!hasCsrfSecret(env))return reply({error:'Administrator setup is temporarily unavailable.'},503);
   const x=await readBody(request,16384),name=String(x.username||'').trim(),password=String(x.password||'');
   if(!/^[A-Za-z0-9_.-]{3,40}$/.test(name))return reply({error:'Username must be 3-40 characters and use letters, numbers, dot, underscore or hyphen'},400);
   if(password.length<12||password.length>1024)return reply({error:'Password must be between 12 and 1,024 characters'},400);
   if(!/[A-Za-z]/.test(password)||!/[0-9]/.test(password))return reply({error:'Password must contain letters and numbers'},400);
   const admins=Number((await db.query("SELECT count(*)::int AS n FROM app_users WHERE role='Admin'"))[0]?.n||0);
   if(admins>0)return reply({error:'An Administrator already exists on this deployment. Contact the deployment owner for recovery.'},409);
   const seed=configuredInitialSetup(env);
   if(!seed)return reply({error:'Administrator setup is disabled. Contact the deployment owner.'},403);
   const ip=request.headers.get('CF-Connecting-IP')||'';
   if(!ip)return reply({error:'Administrator setup is temporarily unavailable.'},429);
   let permitted=false;
   try{permitted=await consumeRateLimit(db,'bootstrap-claim',ip,5,720)}catch{return reply({error:'Administrator setup is temporarily unavailable.'},503)}
   if(!permitted)return reply({error:'Too many attempts. Try again later.'},429,{'Retry-After':'720'});
   // Compare fixed-length digests so the seed value is never returned or logged.
   const [actualName,expectedName,actualPassword,expectedPassword]=await Promise.all([digest(name),digest(seed.username),digest(password),digest(seed.password)]);
   if(!equal(actualName,expectedName)||!equal(actualPassword,expectedPassword))return reply({error:'Administrator setup credentials were not accepted.'},403);
   const existing=await db.query('SELECT id,username,role,salt,password_hash,active FROM app_users WHERE username=$1 LIMIT 1',[name]);
   if(existing.length){
     const usr=existing[0];
     if(!usr.active)return reply({error:'That account is inactive. Ask an Administrator to reactivate it.'},403);
     const ok=equal(await pass(password,usr.salt),usr.password_hash);
     if(!ok)return reply({error:'That username exists and the password did not match. Contact the deployment owner.'},401);
     if(usr.role==='Admin')return reply({error:'An Administrator already exists on this deployment.'},409);
     // Promotion and its session share one statement. If credentials, role or
     // activation changed meanwhile, the stale proof cannot issue an Admin
     // session. A concurrent password update waits for this row lock and then
     // revokes the newly committed session, or wins before the promotion.
     const token=hex(random(48)),tokenHash=await digest(token);
     const promoted=await db.query(`WITH promoted_user AS (
       UPDATE app_users SET role='Admin',updated_at=now()
       WHERE id=$1 AND active=true AND role=$2 AND role<>'Admin' AND salt=$3 AND password_hash=$4 RETURNING id
     ), new_session AS (
       INSERT INTO sessions(id,user_id,token_hash,expires_at)
       SELECT $5,id,$6,$7 FROM promoted_user RETURNING user_id
     ) SELECT user_id FROM new_session`,[usr.id,usr.role,usr.salt,usr.password_hash,crypto.randomUUID(),tokenHash,new Date(Date.now()+TTL).toISOString()]);
     if(!promoted.length)return reply({error:'Account changed during setup. Please retry after review.'},409);
     await audit(db,{id:usr.id,username:usr.username,role:'Admin'},'BOOTSTRAP_ADMIN_PROMOTE','Existing account promoted to first Administrator',request);
     return reply({ok:true,user:{id:usr.id,username:usr.username,role:'Admin'},message:'Administrator created. You can now repair the schema and manage users.'},201,{'Set-Cookie':sessionCookie(token,env)});
   }
   // Do not create another spelling of a legacy account during owner setup.
   if(await usernameExists(db,name))return reply({error:'A differently capitalized account exists. Contact the deployment owner for review.'},409);
   const salt=hex(random(16)),id=crypto.randomUUID(),token=hex(random(48));
   const [hash,tokenHash]=await Promise.all([pass(password,salt),digest(token)]);
   const created=await db.query(`WITH new_user AS (
     INSERT INTO app_users(id,username,role,salt,password_hash) VALUES($1,$2,'Admin',$3,$4)
     ON CONFLICT(username) DO NOTHING RETURNING id
   ), new_session AS (
     INSERT INTO sessions(id,user_id,token_hash,expires_at)
     SELECT $5,id,$6,$7 FROM new_user RETURNING user_id
   ) SELECT user_id FROM new_session`,[id,name,salt,hash,crypto.randomUUID(),tokenHash,new Date(Date.now()+TTL).toISOString()]);
   if(!created.length)return reply({error:'The setup account was created concurrently. Sign in instead.'},409);
   try{await db.query("UPDATE app_bootstrap SET completed_at=now(),completed_by=$1 WHERE id=true",[name])}catch{}
   await audit(db,{id,username:name,role:'Admin'},'BOOTSTRAP_ADMIN','First Administrator created',request);
   return reply({ok:true,user:{id,username:name,role:'Admin'},message:'Administrator created. You can now repair the schema and manage users.'},201,{'Set-Cookie':sessionCookie(token,env)});
  }

  if(u.pathname==='/api/auth/register'&&request.method==='POST'){
   if(!isAuthJson(request))return reply({error:'Use a JSON request.'},415);
   const ip=request.headers.get('CF-Connecting-IP')||'';
   if(!ip||!hasCsrfSecret(env))return reply({error:'Account creation is temporarily unavailable. Please try again later.',code:'AUTH_UNAVAILABLE'},503);
   let permitted=false;
   // Count every attempt atomically, even when auditing is unavailable. A
   // missing limiter must never turn public registration into unlimited sign-up.
   try{permitted=await consumeRateLimit(db,'register',ip,10,360)}catch{return reply({error:'Account creation is temporarily unavailable. Please try again later.',code:'AUTH_UNAVAILABLE'},503)}
   if(!permitted)return reply({error:'Too many account creation attempts. Please wait a few minutes and try again.'},429,{'Retry-After':'360'});
   const x=await readBody(request,16384),inputName=String(x.username||'').trim(),password=String(x.password||'');
   if(!/^[A-Za-z0-9_.-]{3,40}$/.test(inputName))return reply({error:'Username must be 3–40 characters and use letters, numbers, dot, underscore or hyphen'},400);
   if(password.length<12||password.length>1024)return reply({error:'Password must be between 12 and 1,024 characters'},400);
   if(!/[A-Za-z]/.test(password)||!/[0-9]/.test(password))return reply({error:'Password must contain letters and numbers'},400);
   // New public and Admin-created accounts use the same lowercase spelling so
   // the existing username UNIQUE constraint resolves simultaneous sign-ups.
   // Existing names are not rewritten and are checked case-insensitively.
   const name=inputName.toLowerCase(),seed=configuredSeedAdmin(env);
   if((seed&&seed.username.toLowerCase()===name)||await usernameExists(db,name))return reply({error:'That username is already registered or unavailable'},409);
   const salt=hex(random(16)),id=crypto.randomUUID(),token=hex(random(48));
   const [hash,tokenHash]=await Promise.all([pass(password,salt),digest(token)]);
   // One SQL statement makes account and initial session atomic: if creating
   // the session fails, the user insert rolls back instead of stranding an account.
   const created=await db.query(`WITH new_user AS (
     INSERT INTO app_users(id,username,role,salt,password_hash) VALUES($1,$2,'Viewer',$3,$4)
     ON CONFLICT(username) DO NOTHING RETURNING id
   ), new_session AS (
     INSERT INTO sessions(id,user_id,token_hash,expires_at)
     SELECT $5,id,$6,$7 FROM new_user RETURNING user_id
   ) SELECT user_id FROM new_session`,[id,name,salt,hash,crypto.randomUUID(),tokenHash,new Date(Date.now()+TTL).toISOString()]);
   if(!created.length)return reply({error:'That username is already registered or unavailable'},409);
   await audit(db,{id,username:name,role:'Viewer'},'REGISTER','Account created',request);
   return reply({user:{id,username:name,role:'Viewer'},session:'httpOnly-cookie'},201,{'Set-Cookie':sessionCookie(token,env)});
  }
  if(u.pathname==='/api/auth/login'&&request.method==='POST'){
   if(!isAuthJson(request))return reply({error:'Use a JSON request.'},415);
   if(!hasCsrfSecret(env))return reply({error:'Sign-in is temporarily unavailable. Please try again later.',code:'AUTH_UNAVAILABLE'},503);
   const x=await readBody(request,16384),name=String(x.username||'').trim(),password=String(x.password||'');if(!name||!password||name.length>200||password.length>1024)return reply({error:'Username and password are required'},400);
   const loginIp=request.headers.get('CF-Connecting-IP')||'';
   if(!loginIp)return reply({error:'Sign-in is temporarily unavailable. Please try again later.',code:'AUTH_UNAVAILABLE'},503);
   let permitted=false;try{permitted=await consumeRateLimit(db,'login',loginIp,10,90)}catch{return reply({error:'Sign-in is temporarily unavailable. Please try again later.',code:'AUTH_UNAVAILABLE'},503)}
   if(!permitted)return reply({error:'Too many login attempts. Please wait before trying again.'},429,{'Retry-After':'90'});
   // Always prefer an exact legacy spelling. Only allow a case-insensitive
   // lookup when there is one matching account in total, including inactive
   // accounts; ambiguous historical names must use their exact spelling.
   let found=await db.query('SELECT id,username,role,salt,password_hash FROM app_users WHERE username=$1 AND active=true LIMIT 1',[name]);
   if(!found.length){
    const candidates=await db.query('SELECT id,username,role,salt,password_hash,active FROM app_users WHERE lower(username)=lower($1) LIMIT 2',[name]);
    if(candidates.length===1&&candidates[0].active)found=[candidates[0]];
    // Never create a seed account merely because an unrelated or wrong login
    // was attempted. Initial creation requires the explicit setup switch, the
    // configured identity and matching secret, and no Admin (even inactive).
    // A legacy case-variant (active or inactive) also blocks seed creation.
    const seed=configuredInitialSetup(env);
    if(!found.length&&!candidates.length&&seed&&name===seed.username&&equal(await digest(password),await digest(seed.password))){
     const admins=Number((await db.query("SELECT count(*)::int AS n FROM app_users WHERE role='Admin'"))[0]?.n||0);
     if(admins===0){
      const salt=hex(random(16)),id=crypto.randomUUID(),t=hex(random(48));
      const [hash,tokenHash]=await Promise.all([pass(password,salt),digest(t)]);
      const created=await db.query(`WITH new_user AS (
        INSERT INTO app_users(id,username,role,salt,password_hash) VALUES($1,$2,'Admin',$3,$4)
        ON CONFLICT(username) DO NOTHING RETURNING id
      ), new_session AS (
        INSERT INTO sessions(id,user_id,token_hash,expires_at)
        SELECT $5,id,$6,$7 FROM new_user RETURNING user_id
      ) SELECT user_id FROM new_session`,[id,seed.username,salt,hash,crypto.randomUUID(),tokenHash,new Date(Date.now()+TTL).toISOString()]);
      if(created.length){
       const initial={id,username:seed.username,role:'Admin'};
       await audit(db,initial,'LOGIN','Successful login after initial seed setup',request);
       return reply({user:initial,session:'httpOnly-cookie'},200,{'Set-Cookie':sessionCookie(t,env)});
      }
      found=await db.query('SELECT id,username,role,salt,password_hash FROM app_users WHERE username=$1 AND active=true LIMIT 1',[name]);
     }
    }
   }
   const usr=found[0];if(!usr){await pass(password,'00000000000000000000000000000000');await audit(db,null,'LOGIN_FAILED','Unknown user',request);return reply({error:'Invalid credentials'},401)}
   if(!equal(await pass(password,usr.salt),usr.password_hash)){
    const seedName=String(env.SEED_ADMIN_USERNAME||''),seedPassword=String(env.SEED_ADMIN_PASSWORD||'');
    const mayRecover=usr.role==='Admin'&&name===seedName&&password===seedPassword&&usr.username===seedName&&seedPassword.length>=12&&!/change-?me|replace/i.test(seedPassword);
    if(!mayRecover){await audit(db,usr,'LOGIN_FAILED','Bad password',request);return reply({error:'Invalid credentials'},401)}
    if(typeof db.transaction!=='function')return reply({error:'Administrator recovery is temporarily unavailable.',code:'AUTH_UNAVAILABLE'},503);
    const salt=hex(random(16)),hash=await pass(password,salt),t=hex(random(48));
    const tokenHash=await digest(t),sessionId=crypto.randomUUID(),expires=new Date(Date.now()+TTL).toISOString();
    // Recovery remains available for the exact configured seed Admin. Like a
    // password change, it must not overwrite a concurrent credential update or
    // leave sessions issued under the old credentials alive. The fresh login
    // session is created in the same transaction, or all three writes roll back.
    const recovered=await db.transaction(tx=>[
     tx.query(`UPDATE app_users SET salt=$1,password_hash=$2,updated_at=now()
       WHERE id=$3 AND active=true AND role='Admin' AND username=$4 AND salt=$5 AND password_hash=$6 RETURNING id`,
       [salt,hash,usr.id,usr.username,usr.salt,usr.password_hash]),
     tx.query(`UPDATE sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL
       AND EXISTS (SELECT 1 FROM app_users WHERE id=$1 AND active=true AND role='Admin' AND username=$2 AND salt=$3 AND password_hash=$4) RETURNING id`,
       [usr.id,usr.username,salt,hash]),
     tx.query(`INSERT INTO sessions(id,user_id,token_hash,expires_at)
       SELECT $1,id,$2,$3 FROM app_users WHERE id=$4 AND active=true AND role='Admin' AND username=$5 AND salt=$6 AND password_hash=$7 RETURNING user_id`,
       [sessionId,tokenHash,expires,usr.id,usr.username,salt,hash])
    ],{isolationLevel:'ReadCommitted'});
    if(!Array.isArray(recovered)||recovered.length!==3||recovered.some(rows=>!Array.isArray(rows)))throw Error('Administrator recovery result could not be confirmed');
    if(!recovered[0].length&&!recovered[1].length&&!recovered[2].length)return reply({error:'The account credentials changed while signing in. Please try again.',code:'AUTH_CREDENTIALS_CHANGED'},401);
    if(recovered[0].length!==1||recovered[0][0].id!==usr.id||recovered[2].length!==1||recovered[2][0].user_id!==usr.id)throw Error('Administrator recovery result could not be confirmed');
    await audit(db,usr,'ADMIN_SEED_RECOVERY','Seed recovery completed; existing sessions revoked',request);
    await audit(db,usr,'LOGIN','Successful login after seed recovery',request);
    return reply({user:{id:usr.id,username:usr.username,role:usr.role},session:'httpOnly-cookie',seedRecovery:true,otherSessionsRevoked:true},200,{'Set-Cookie':sessionCookie(t,env)});
   }
   // Recheck the verified credentials while holding the account row lock until
   // this insert commits. A password change using the same lock cannot leave a
   // session created later from a password that was already replaced.
   const t=hex(random(48));
   const issued=await db.query(`WITH verified_user AS (
     SELECT id FROM app_users WHERE id=$1 AND active=true AND salt=$2 AND password_hash=$3 FOR UPDATE
   ) INSERT INTO sessions(id,user_id,token_hash,expires_at)
     SELECT $4,id,$5,$6 FROM verified_user RETURNING user_id`,
     [usr.id,usr.salt,usr.password_hash,crypto.randomUUID(),await digest(t),new Date(Date.now()+TTL).toISOString()]);
   if(!issued.length)return reply({error:'The account credentials changed while signing in. Please try again.',code:'AUTH_CREDENTIALS_CHANGED'},401);
   await audit(db,usr,'LOGIN','Successful login',request);return reply({user:{id:usr.id,username:usr.username,role:usr.role},session:'httpOnly-cookie'},200,{'Set-Cookie':sessionCookie(t,env)});
  }
  if(u.pathname==='/api/csrf'&&request.method==='GET'){const t=rawToken(request);if(!t)return reply({error:'Authentication required'},401);return reply({token:await csrf(t,env.CSRF_SECRET||env.SESSION_SECRET||'')})}
  if(u.pathname==='/api/auth/logout'&&request.method==='POST'){const me=await userFor(db,request);if(!me)return reply({error:'Authentication required'},401);if(!await validCsrf(request,env))return reply({error:'CSRF protection: missing or invalid X-CSRF-Token'},403);await db.query('UPDATE sessions SET revoked_at=now() WHERE token_hash=$1',[await digest(rawToken(request))]);await audit(db,me,'LOGOUT','Session revoked',request);return reply({ok:true},200,{'Set-Cookie':C+'=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax'+((env.DB_ADAPTER&&env.COOKIE_SECURE==='false')?'':'; Secure')})}
  const me=await userFor(db,request);
  if(u.pathname==='/api/arena/catalogue'&&request.method==='GET')return reply(arenaCatalogue(env));
  // Static metadata (no account data) — a signed-out visitor must still be able to read
  // what this arena does and does not do. Rendered by arena.html before sign-in.
  if(u.pathname==='/api/arena/features'&&request.method==='GET'&&!me)return await arenaRoute({request,env,db,me:null,url:u,readBody,reply,audit,consumeRateLimit,onRequest});
  if(u.pathname==='/api/arena/prompts'&&request.method==='GET'&&!me)return await arenaRoute({request,env,db,me:null,url:u,readBody,reply,audit,consumeRateLimit,onRequest});
  // The toolbox catalogue is a static list of what the runtime can do. Publishing it
  // before sign-in lets Toolbench explain the product without inventing a list.
  if(u.pathname==='/api/agent/capabilities'&&request.method==='GET'&&!me)return await agentRoute({request,env,db,me:null,url:u,readBody,reply,audit,consumeRateLimit,onRequest});
  if(u.pathname==='/api/me'&&request.method==='GET')return reply(me?{authenticated:true,user:{id:me.id,username:me.username,role:me.role},csrfToken:await csrf(rawToken(request),env.CSRF_SECRET||env.SESSION_SECRET||'')}:{authenticated:false,user:null,csrfToken:null});
  if(!me)return reply({error:'Authentication required'},401);
  if(['POST','PUT','PATCH','DELETE'].includes(request.method)&&!await validCsrf(request,env))return reply({error:'CSRF protection: missing or invalid X-CSRF-Token'},403);
  const reportResponse=await contentReportRoute({request,db,me,url:u,readBody,reply,audit,consumeRateLimit});if(reportResponse)return reportResponse;
  const assistantResponse=await assistantRoute({request,env,db,me,url:u,readBody,reply,audit,consumeRateLimit,onRequest});if(assistantResponse)return assistantResponse;
  const platformResponse=await platformRoute({request,env,db,me,url:u,readBody,reply,audit,consumeRateLimit,onRequest});if(platformResponse)return platformResponse;
  const agentResponse=await agentRoute({request,env,db,me,url:u,readBody,reply,audit,consumeRateLimit,onRequest});if(agentResponse)return agentResponse;
  const arenaResponse=await arenaRoute({request,env,db,me,url:u,readBody,reply,audit,consumeRateLimit,onRequest});if(arenaResponse)return arenaResponse;
  if(u.pathname==='/api/voice/speak'&&request.method==='POST'){
   if(providerConfiguration(env,'elevenlabs')===null)return reply({error:'Stored voice-provider settings could not be read. Configuration is unknown; no voice-provider request was made.',code:'PROVIDER_STATUS_UNKNOWN'},503);
   if(!env.ELEVENLABS_API_KEY)return reply({error:'ElevenLabs is not configured on the cloud project yet.',code:'VOICE_PROVIDER_NOT_CONFIGURED'},503);
   const voiceId=String(env.ELEVENLABS_VOICE_ID||'').trim();
   if(!voiceId)return reply({error:'ELEVENLABS_VOICE_ID is not configured on the cloud project.',code:'VOICE_ID_NOT_CONFIGURED'},503);
   const x=await readBody(request),speech=String(x.text||'').trim();
   if(!speech)return reply({error:'There is no reply text to speak.'},400);
   if(speech.length>2500)return reply({error:'Voice text is too long (maximum 2,500 characters).'},413);
   const count=await db.query("SELECT count(*)::int AS n FROM audit_events WHERE user_id=$1 AND action='VOICE_SPEAK_REQUEST' AND created_at>now()-interval '1 hour'",[me.id]);
   if(Number(count[0]?.n||0)>=30)return reply({error:'Voice limit reached (30 requests per hour). Please wait and retry.'},429,{'Retry-After':'3600'});
   await db.query('INSERT INTO audit_events(id,user_id,action,detail,ip,request_id) VALUES($1,$2,$3,$4,$5,$6)',[crypto.randomUUID(),me.id,'VOICE_SPEAK_REQUEST','ElevenLabs text-to-speech requested; text is not stored by the app',request.headers.get('CF-Connecting-IP')||'',request.headers.get('cf-ray')||null]);
   let upstream;
   try{upstream=await fetch('https://api.elevenlabs.io/v1/text-to-speech/'+encodeURIComponent(voiceId),{method:'POST',headers:{'xi-api-key':env.ELEVENLABS_API_KEY,'Content-Type':'application/json','Accept':'audio/mpeg'},body:JSON.stringify({text:speech,model_id:env.ELEVENLABS_MODEL_ID||'eleven_multilingual_v2',voice_settings:{stability:0.5,similarity_boost:0.75}}),signal:AbortSignal.timeout(20000)})}catch{return reply({error:'ElevenLabs could not be reached. Please retry shortly.',code:'VOICE_UPSTREAM_UNAVAILABLE'},502)}
   if(!upstream.ok){const status=upstream.status;return reply({error:status===401||status===403?'ElevenLabs rejected the cloud credentials or voice access.':status===429?'ElevenLabs rate limit reached. Please retry later.':'ElevenLabs could not generate speech.',code:'VOICE_GENERATION_FAILED',upstreamStatus:status},502)}
   const audio=await upstream.arrayBuffer();if(!audio.byteLength||audio.byteLength>12*1024*1024)return reply({error:'Generated audio was empty or exceeded the 12 MB limit.'},502);
   return new Response(audio,{status:200,headers:{'Content-Type':'audio/mpeg','Content-Length':String(audio.byteLength),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Disposition':'inline; filename=jalalai-reply.mp3'}})
  }
  if(u.pathname==='/api/ai/run'&&request.method==='POST'){
   const x=await readBody(request,24*1024*1024),privacyMode=x.privacyMode===true;
   if(x.thinking===true)return reply({ok:false,error:'Extended thinking is not implemented by this endpoint. Use the provider’s normal model settings.',code:'THINKING_CONTROL_UNAVAILABLE'},400);
   if(!await consumeRateLimit(db,'ai-minute',me.id,20,3))return reply({error:'AI request limit reached (20 per minute). Please wait and retry.'},429,{'Retry-After':'60'});
   if(!await consumeRateLimit(db,'ai-day',me.id,200,432))return reply({error:'Daily AI request limit reached (200 per day). Please retry tomorrow.'},429,{'Retry-After':'3600'});
   const prompt=String(x.prompt||'').trim(),agentId=String(x.agentId||'general').slice(0,80),attachments=Array.isArray(x.attachments)?x.attachments:[];
   if(privacyMode)await audit(db,me,'AI_CHAT_REQUEST','Private cloud chat request; prompt and response are not stored by the app',request);
   if(!prompt)return reply({error:'Enter a prompt before running the assistant'},400);
   if(prompt.length>10000)return reply({error:'Prompt is too long (maximum 10,000 characters)'},413);
   if(attachments.length>4)return reply({error:'Attach no more than four images per message'},413);
   const imageAttachments=[];for(const item of attachments){const type=String(item?.type||'').toLowerCase(),dataUrl=String(item?.dataUrl||'');if(!type.startsWith('image/')||!/^data:image\/(png|jpeg|jpg|webp|gif);base64,[a-z0-9+/=]+$/i.test(dataUrl))return reply({error:'Invalid image attachment. Supported images: PNG, JPEG, WEBP, or GIF.'},400);if(dataUrl.length>5_600_000)return reply({error:'Each image must be 4 MB or smaller'},413);imageAttachments.push({type,dataUrl,name:String(item?.name||'image').slice(0,180)})}
   const configs={
    openai:{key:env.OPENAI_API_KEY,model:env.OPENAI_MODEL||'gpt-4o-mini',label:'OpenAI / ChatGPT'},
    anthropic:{key:env.ANTHROPIC_API_KEY,model:env.ANTHROPIC_MODEL||'claude-3-5-haiku-latest',label:'Anthropic / Claude'},
    deepseek:{key:env.DEEPSEEK_API_KEY,model:env.DEEPSEEK_MODEL||'deepseek-chat',label:'DeepSeek'},
    gemini:{key:env.GEMINI_API_KEY,model:env.GEMINI_MODEL||'gemini-2.5-flash',label:'Google Gemini'},
    omniroute:{key:env.OMNIROUTE_API_KEY||env.OMNIROUTE_KEY,model:env.OMNIROUTE_MODEL||'openai/gpt-4o-mini',label:'OmniRoute'}
   };
   let provider=String(x.provider||'gemini').toLowerCase().slice(0,40);
   if(provider==='openai-compatible')provider='openai';
   if(provider==='auto')provider=['gemini','openai','anthropic','deepseek','omniroute'].find(k=>providerConfiguration(env,k)===true)||'gemini';
   const cfg=configs[provider];
   if(!cfg)return reply({ok:false,error:'Unsupported provider. Choose OpenAI, Claude, DeepSeek, Gemini, or a configured OmniRoute endpoint.',code:'UNSUPPORTED_PROVIDER'},400);
   const traceId=crypto.randomUUID(),model=String(x.model||cfg.model).trim();
   if(!model||model.length>120||!/^[A-Za-z0-9._:/-]+$/.test(model))return reply({error:'Invalid model identifier (maximum 120 safe characters)'},400);
   const saveRun=async(status,output,trace)=>privacyMode?[]:db.query('INSERT INTO ai_runs(id,user_id,agent_id,provider,model,prompt,output,status,tool_calls,trace) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,$10::jsonb) RETURNING created_at',[traceId,me.id,agentId,provider,model,prompt,output,status,JSON.stringify([]),JSON.stringify(trace)]);
   const configured=providerConfiguration(env,provider);
   if(configured===null){
    const output='Stored provider settings could not be read. Configuration is unknown; no cloud request was made.';
    const row=await saveRun('failed',output,{mode:'provider_status_unknown',provider,thinking:Boolean(x.thinking)});
    await audit(db,me,'AI_RUN_PROVIDER_STATUS_UNKNOWN',provider,request);
    return reply({ok:false,traceId,provider,model,status:'failed',code:'PROVIDER_STATUS_UNKNOWN',simulated:false,error:output+' Retry when settings are available or use local tools.',createdAt:row[0]?.created_at},503);
   }
   if(configured===false){
    const omni=provider==='omniroute';
    const output=omni?'No external AI call was made because OmniRoute requires a server-side key and endpoint.':'No external AI call was made because this provider has no server-side API key configured.';
    const row=await saveRun('not_configured',output,{mode:'not_configured',provider,thinking:Boolean(x.thinking)});
    await audit(db,me,'AI_RUN_NOT_CONFIGURED',provider,request);
    const error=omni?'OmniRoute is not configured. An administrator must set both its server-side API key and HTTPS endpoint.':'This provider is not configured yet. Add its API key in Cloudflare Pages environment variables, then retry.';
    return reply({ok:false,traceId,provider,model,status:'not_configured',simulated:false,error,createdAt:row[0]?.created_at},503);
   }
   const agentNames={general:'Power AI Assistant',research:'Research Assistant',coding:'Coding Assistant',creative:'Creative Assistant',analysis:'Analysis Assistant',nexus:'General Assistant',aether:'Creative & Code Assistant',deepreason:'Reasoning Assistant',titan:'Fast Assistant',superpower:'Superpower Agent', 'open-gpt':'OpenGPT Assistant','ux-ui-pro-max':'UX/UI Pro Max',omniroute:'OmniRoute Assistant',omniverse:'Omniverse Intelligence','mission-orchestrator':'Mission Orchestrator','knowledge-vault':'Knowledge Vault','voice-agent':'Voice Assistant','health-agent':'Health Information Assistant',supervisor:'Supervisor Agent',autogpt:'AutoGPT Planner'};
   const specialistRules=agentId==='health-agent'?' For health topics, provide general educational information only, do not diagnose or prescribe, flag emergencies, and encourage qualified clinical care; state uncertainty and do not invent citations.':agentId==='ux-ui-pro-max'?' Focus on professional UX/UI, accessibility, responsive layouts, design tokens, and actionable implementation steps.':agentId==='mission-orchestrator'||agentId==='superpower'||agentId==='supervisor'||agentId==='autogpt'?' Break work into bounded steps, identify required tools and approvals, and never claim an external action ran unless a tool actually executed.':agentId==='voice-agent'?' Provide voice-agent design and scripts in text; do not claim audio capture or speech synthesis is active in this text API.':agentId==='knowledge-vault'?' Distinguish information actually provided or retrieved from assumptions; do not claim access to saved files unless a retrieval tool ran.':'';
   const systemPrompt='You are Al-Syed Jalal AI, a careful and capable '+(agentNames[agentId]||'Workspace Assistant')+'. Give useful, structured answers. Be honest about uncertainty and never claim to have run tools, browsed the web, edited files, or completed external actions unless those actions actually occurred.'+specialistRules;
   let url='',headers={'content-type':'application/json'},payload={};
   if(provider==='openai'||provider==='deepseek'||provider==='omniroute'){
    if(provider==='openai'){url='https://api.openai.com/v1/chat/completions';headers.authorization='Bearer '+cfg.key;}
    else if(provider==='deepseek'){url='https://api.deepseek.com/chat/completions';headers.authorization='Bearer '+cfg.key;}
    else {const base=String(env.OMNIROUTE_BASE_URL||env.OMNIROUTE_URL||'').trim().replace(/\/+$/,'');if(!base)return reply({ok:false,traceId,provider,model,status:'not_configured',error:'OMNIROUTE_BASE_URL is not configured on the server.'},503);try{if(new URL(base).protocol!=='https:')return reply({ok:false,error:'OmniRoute base URL must use HTTPS.'},400);}catch{return reply({ok:false,error:'OmniRoute base URL is invalid.'},400);}url=/\/chat\/completions$/i.test(base)?base:base+'/chat/completions';headers.authorization='Bearer '+cfg.key;}
    const userContent=imageAttachments.length?[{type:'text',text:prompt},...imageAttachments.map(a=>({type:'image_url',image_url:{url:a.dataUrl}}))]:prompt;if(imageAttachments.length&&provider==='deepseek')return reply({ok:false,error:'The selected DeepSeek endpoint is not enabled for image analysis here. Choose a vision-capable OpenAI, Gemini, Claude, or OmniRoute model.'},400);payload={model,messages:[{role:'system',content:systemPrompt},{role:'user',content:userContent}],temperature:0.4,max_tokens:2048};
   } else if(provider==='anthropic'){
    url='https://api.anthropic.com/v1/messages';headers['x-api-key']=cfg.key;headers['anthropic-version']='2023-06-01';
    const userContent=imageAttachments.length?[{type:'text',text:prompt},...imageAttachments.map(a=>({type:'image',source:{type:'base64',media_type:a.type,data:a.dataUrl.split(',')[1]}}))]:prompt;payload={model,max_tokens:2048,system:systemPrompt,messages:[{role:'user',content:userContent}]};
   } else {
    url='https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(model)+':generateContent';headers['x-goog-api-key']=cfg.key;
    const parts=[{text:prompt},...imageAttachments.map(a=>({inline_data:{mime_type:a.type,data:a.dataUrl.split(',')[1]}}))];payload={systemInstruction:{parts:[{text:systemPrompt}]},contents:[{role:'user',parts}],generationConfig:{maxOutputTokens:2048}};
   }
   let upstream,data;
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),45000);
   try{for(let attempt=0;attempt<3;attempt++){upstream=await fetch(url,{method:'POST',headers,body:JSON.stringify(payload),signal:controller.signal});data=await upstream.json().catch(err=>{if(controller.signal.aborted||err?.name!=='SyntaxError')throw err;return {}});if(controller.signal.aborted)throw Object.assign(new Error('Provider response timed out'),{name:'AbortError'});if(upstream.ok||![408,429,500,502,503,504].includes(upstream.status)||attempt===2)break;await new Promise(resolve=>setTimeout(resolve,900*(2**attempt)));}}
   catch(err){clearTimeout(timer);const msg=controller.signal.aborted?'Provider request timed out after 45 seconds.':'Could not reach the selected AI provider.';const row=await saveRun('failed',msg,{mode:'provider_error',provider,model,error:err?.name||'network_error'});await audit(db,me,'AI_RUN_FAILED',provider+': network/timeout',request);return reply({ok:false,traceId,provider,model,status:'failed',error:msg,createdAt:row[0]?.created_at},502);}
   finally{clearTimeout(timer);}
   if(!upstream.ok){
    // Provider error bodies can echo request data or secrets. Use them only to
    // identify overload, never return or persist their untrusted text.
    const providerMessage=String(data?.error?.message||data?.message||'');
    const overloaded=upstream.status===503&&(provider==='gemini'||/high demand|overload|temporarily unavailable/i.test(providerMessage));
    const auth=upstream.status===401||upstream.status===403,quota=upstream.status===429,modelMissing=upstream.status===404,badRequest=upstream.status===400;
    const msg=overloaded?'The AI provider is temporarily overloaded (HTTP 503). Automatic retries were attempted. Wait 30–60 seconds and retry; if this keeps happening, configure a second provider key in Cloudflare Pages and select that provider. No automatic provider failover is active.'
     :auth?`The AI provider rejected credentials or model access (HTTP ${upstream.status}). An administrator should check the server-side key and model permissions; never share a key in chat.`
     :quota?'The AI provider reported a rate limit or quota problem (HTTP 429). Check its account limits and retry later.'
     :modelMissing?'The AI provider could not find the selected model or endpoint (HTTP 404). Check the configured model and endpoint.'
     :badRequest?'The AI provider rejected the request (HTTP 400). Check the configured model and request settings.'
     :`Provider request failed (HTTP ${upstream.status}). Check provider availability, model access and quota.`;
    const retryAfter=overloaded?60:null,code=overloaded?'PROVIDER_OVERLOADED':auth?'PROVIDER_ACCESS_REJECTED':quota?'PROVIDER_RATE_OR_QUOTA':modelMissing?'PROVIDER_MODEL_NOT_FOUND':badRequest?'PROVIDER_BAD_REQUEST':'PROVIDER_UPSTREAM_ERROR';
    const row=await saveRun('failed',msg,{mode:'provider_error',provider,model,httpStatus:upstream.status,retryable:[408,429,500,502,503,504].includes(upstream.status),retryAfterSeconds:retryAfter});
    await audit(db,me,'AI_RUN_FAILED',provider+': HTTP '+upstream.status,request);
    return reply({ok:false,traceId,provider,model,status:'failed',error:msg,code,retryable:[408,429,500,502,503,504].includes(upstream.status),retryAfterSeconds:retryAfter,providerStatus:upstream.status,createdAt:row[0]?.created_at},502,overloaded?{'Retry-After':'60'}:{});
   }
   let output='';
   if(provider==='openai'||provider==='deepseek'||provider==='omniroute'){const v=data?.choices?.[0]?.message?.content;output=Array.isArray(v)?v.map(z=>z?.text||'').join('\n'):String(v||'');}
   else if(provider==='anthropic')output=(data?.content||[]).filter(z=>z?.type==='text').map(z=>z.text||'').join('\n');
   else output=(data?.candidates?.[0]?.content?.parts||[]).map(z=>z?.text||'').join('\n');
   if(!output.trim()){const msg='The provider returned no text output. Check the model and request settings.';const row=await saveRun('failed',msg,{mode:'provider_error',provider,model,reason:'empty_output'});await audit(db,me,'AI_RUN_FAILED',provider+': empty output',request);return reply({ok:false,traceId,provider,model,status:'failed',error:msg,createdAt:row[0]?.created_at},502);}
   const row=await saveRun('completed',output,{mode:'live',provider,model,thinking:Boolean(x.thinking),providerRequestCompleted:true});
   await audit(db,me,'AI_RUN_COMPLETED',provider+': '+model,request);
   return reply({ok:true,traceId,agentId,provider,model,status:'completed',simulated:false,output,createdAt:row[0]?.created_at});
  }
  if(u.pathname==='/api/ai/runs'&&request.method==='GET'){
   const limit=Math.min(50,Math.max(1,Number(u.searchParams.get('limit')||20)));
   const rows=await db.query('SELECT id,agent_id,provider,model,prompt,output,status,created_at FROM ai_runs WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2',[me.id,limit]);
   return reply({runs:rows.map(r=>({id:r.id,traceId:r.id,agentId:r.agent_id,provider:r.provider,model:r.model,prompt:r.prompt,output:r.output,status:r.status,createdAt:r.created_at})),count:rows.length});
  }
  if(u.pathname==='/api/auth/me'&&request.method==='GET')return reply({authenticated:true,user:{id:me.id,username:me.username,role:me.role},csrfToken:await csrf(rawToken(request),env.CSRF_SECRET||env.SESSION_SECRET||'')});
  if(u.pathname==='/api/auth/sessions'&&request.method==='GET'){const rows=await db.query('SELECT id,created_at AS createdat,expires_at AS expiresat,revoked_at AS revokedat,(revoked_at IS NULL AND expires_at>now()) AS active FROM sessions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[me.id]);return reply({sessions:rows.map(x=>({id:x.id,createdAt:x.createdat,expiresAt:x.expiresat,revokedAt:x.revokedat,active:x.active,current:x.id===me.session_id}))})}
  if(u.pathname==='/api/auth/sessions'&&request.method==='DELETE'){await db.query('UPDATE sessions SET revoked_at=now() WHERE user_id=$1 AND id<>$2 AND revoked_at IS NULL',[me.id,me.session_id]);await audit(db,me,'SESSION_REVOKE_ALL','Other active sessions revoked',request);return reply({ok:true})}
  if(u.pathname==='/api/records'&&request.method==='GET'){const page=Math.max(1,Number(u.searchParams.get('page')||1)),limit=Math.min(200,Math.max(1,Number(u.searchParams.get('limit')||100))),term=(u.searchParams.get('q')||'').slice(0,200),like='%'+term+'%',region=(u.searchParams.get('region')||'').slice(0,200),sector=(u.searchParams.get('sector')||'').slice(0,200),off=(page-1)*limit,where="deleted_at IS NULL AND ($1='' OR id ILIKE $2 OR name ILIKE $2 OR region ILIKE $2 OR sector ILIKE $2 OR status ILIKE $2 OR notes ILIKE $2) AND ($3='' OR region=$3) AND ($4='' OR sector=$4)";const [rs,cs]=await Promise.all([db.query('SELECT id,name,region,sector,status,notes,updated_at AS updatedat FROM records WHERE '+where+' ORDER BY updated_at DESC,id ASC LIMIT $5 OFFSET $6',[term,like,region,sector,limit,off]),db.query('SELECT count(*)::int AS n FROM records WHERE '+where,[term,like,region,sector])]);return reply({records:rs.map(r=>({id:r.id,name:r.name,region:r.region,sector:r.sector,status:r.status,notes:r.notes,updatedAt:r.updatedat})),total:Number(cs[0]?.n||0),page,limit,pages:Math.max(1,Math.ceil(Number(cs[0]?.n||0)/limit))})}
  if(u.pathname==='/api/records'&&request.method==='POST'){
   if(!WRITERS.includes(me.role))return reply({error:'Role not permitted'},403);
   const x=await readBody(request);let r;try{[r]=normalizeRecords([x])}catch(e){return reply({error:e.message},400)}
   if(!r.id)r.id='AJ-'+crypto.randomUUID().toUpperCase();
   // One PostgreSQL statement: if writing the history fails, the insert rolls back.
   // Return database values, not the request, so callers can detect changes by
   // database defaults or BEFORE triggers rather than receiving false confirmation.
   const a=await db.query("WITH created AS (INSERT INTO records(id,name,region,sector,status,notes,created_by,updated_by) VALUES($1,$2,$3,$4,$5,$6,$7,$7) RETURNING *), logged AS (INSERT INTO record_history(id,record_id,user_id,action,snapshot) SELECT $8,id,$7,'CREATE',to_jsonb(created) FROM created RETURNING record_id) SELECT created.id,created.name,created.region,created.sector,created.status,created.notes FROM created JOIN logged ON logged.record_id=created.id",[r.id,r.name,r.region,r.sector,r.status,r.notes,me.id,crypto.randomUUID()]);
   if(!a[0])return reply({error:'Record creation could not be confirmed'},500);
   await audit(db,me,'CREATE',a[0].id,request);return reply({record:{id:a[0].id,name:a[0].name,region:a[0].region,sector:a[0].sector,status:a[0].status,notes:a[0].notes}},201);
  }
  if(p[1]==='records'&&p.length===3){const id=decodeURIComponent(p[2]);if(request.method==='GET'){const a=await db.query('SELECT id,name,region,sector,status,notes,updated_at AS updatedat,xmin::text AS version FROM records WHERE id=$1 AND deleted_at IS NULL LIMIT 1',[id]);if(!a[0])return reply({error:'Not found'},404);const r=a[0];return reply({record:{id:r.id,name:r.name,region:r.region,sector:r.sector,status:r.status,notes:r.notes,updatedAt:r.updatedat,version:r.version}})}
   if(request.method==='PUT'){
    if(!WRITERS.includes(me.role))return reply({error:'Role not permitted'},403);
    const x=await readBody(request);let patch;try{patch=normalizeRecordPatch(x)}catch(e){return reply({error:e.message},400)}
    // Optional for older API clients. The current editor supplies the version
    // from its initial read so a concurrent change cannot be overwritten.
    const hasExpected=Object.hasOwn(x,'expectedVersion'),expected=hasExpected?x.expectedVersion:null;
    if(hasExpected&&(typeof expected!=='string'||!/^\d{1,20}$/.test(expected)))return reply({error:'Invalid record version'},400);
    const a=await db.query("WITH changed AS (UPDATE records SET name=COALESCE($2,name),region=COALESCE($3,region),sector=COALESCE($4,sector),status=COALESCE($5,status),notes=COALESCE($6,notes),updated_by=$7,updated_at=now() WHERE id=$1 AND deleted_at IS NULL AND ($9::text IS NULL OR xmin::text=$9) RETURNING *), logged AS (INSERT INTO record_history(id,record_id,user_id,action,snapshot) SELECT $8,id,$7,'UPDATE',to_jsonb(changed) FROM changed RETURNING record_id) SELECT changed.id,changed.name,changed.region,changed.sector,changed.status,changed.notes,changed.updated_at AS updatedat FROM changed JOIN logged ON logged.record_id=changed.id",[id,patch.name,patch.region,patch.sector,patch.status,patch.notes,me.id,crypto.randomUUID(),expected]);
    if(!a[0]){
     if(expected!==null&&(await db.query('SELECT id FROM records WHERE id=$1 AND deleted_at IS NULL LIMIT 1',[id]))[0])return reply({error:'Record changed elsewhere. Close and reopen it to review before saving.',code:'RECORD_CONFLICT'},409);
     return reply({error:'Not found'},404);
    }
    await audit(db,me,'UPDATE',id,request);const r=a[0];return reply({record:{id:r.id,name:r.name,region:r.region,sector:r.sector,status:r.status,notes:r.notes,updatedAt:r.updatedat}});
   }
   if(request.method==='DELETE'){
    if(!['Admin','Manager'].includes(me.role))return reply({error:'Role not permitted'},403);
    const a=await db.query("WITH changed AS (UPDATE records SET deleted_at=now(),deleted_by=$2,updated_by=$2,updated_at=now() WHERE id=$1 AND deleted_at IS NULL RETURNING *), logged AS (INSERT INTO record_history(id,record_id,user_id,action,snapshot) SELECT $3,id,$2,'SOFT_DELETE',to_jsonb(changed) FROM changed RETURNING record_id) SELECT changed.id,changed.deleted_at AS deletedat FROM changed JOIN logged ON logged.record_id=changed.id",[id,me.id,crypto.randomUUID()]);
    if(!a[0])return reply({error:'Not found'},404);
    if(!a[0].deletedat)return reply({error:'Record deletion could not be confirmed'},500);
    await audit(db,me,'SOFT_DELETE',id,request);return reply({ok:true,softDeleted:true});
   }}
  if(u.pathname==='/api/meta'&&request.method==='GET'){const [r,s]=await Promise.all([db.query("SELECT DISTINCT region FROM records WHERE region<>'' AND deleted_at IS NULL ORDER BY region"),db.query("SELECT DISTINCT sector FROM records WHERE sector<>'' AND deleted_at IS NULL ORDER BY sector")]);return reply({regions:r.map(x=>x.region),sectors:s.map(x=>x.sector)})}
  if(u.pathname==='/api/stats'&&request.method==='GET'){if(me.role!=='Admin')return reply({error:'Admin role required for workspace-wide statistics'},403);const [t,r,s,a,d]=await Promise.all([db.query('SELECT count(*)::int AS n FROM records WHERE deleted_at IS NULL'),db.query('SELECT region,count(*)::int AS n FROM records WHERE deleted_at IS NULL GROUP BY region ORDER BY n DESC'),db.query('SELECT sector,count(*)::int AS n FROM records WHERE deleted_at IS NULL GROUP BY sector ORDER BY n DESC'),db.query('SELECT count(*)::int AS n FROM audit_events'),db.query('SELECT count(*)::int AS n FROM app_users WHERE active=true')]);return reply({total:Number(t[0]?.n||0),regions:Object.fromEntries(r.map(x=>[x.region||'Unassigned',Number(x.n)])),sectors:Object.fromEntries(s.map(x=>[x.sector||'Unassigned',Number(x.n)])),auditCount:Number(a[0]?.n||0),activeUsers:Number(d[0]?.n||0)})}
  if(u.pathname==='/api/approvals'&&request.method==='GET'){const a=await db.query("SELECT id,action,description,status,requested_by AS requestedby,created_at AS createdat,resolved_at AS resolvedat,resolved_by AS resolvedby FROM approvals WHERE status='pending' ORDER BY created_at ASC LIMIT 100");return reply({approvals:a.map(x=>({id:x.id,action:x.action,description:x.description,status:x.status,requestedBy:x.requestedby,createdAt:x.createdat,resolvedAt:x.resolvedat,resolvedBy:x.resolvedby}))})}
  if(u.pathname==='/api/approvals'&&request.method==='POST'){if(!['Admin','Manager'].includes(me.role))return reply({error:'Manager or Admin role required'},403);const x=await readBody(request),action=String(x.action||'').trim(),description=String(x.description||'').trim();if(!action||action.length>200)return reply({error:'action is required (maximum 200 characters)'},400);if(description.length>2000)return reply({error:'description must be at most 2,000 characters'},400);const id=crypto.randomUUID();await db.query('INSERT INTO approvals(id,action,description,requested_by) VALUES($1,$2,$3,$4)',[id,action,description,me.username]);await audit(db,me,'APPROVAL_REQUESTED',action+' · '+description,request);return reply({ok:true,approval:{id,action,description,status:'pending',requestedBy:me.username}},201)}
  if(p[1]==='approvals'&&p.length===3&&['PATCH','POST'].includes(request.method)){if(!['Admin','Manager'].includes(me.role))return reply({error:'Manager or Admin role required'},403);const x=await readBody(request),status=String(x.status||'');if(!['approved','rejected'].includes(status))return reply({error:'status must be approved or rejected'},400);const a=await db.query("UPDATE approvals SET status=$2,resolved_at=now(),resolved_by=$3 WHERE id=$1 AND status='pending' RETURNING id,action,description,status,requested_by AS requestedby,created_at AS createdat,resolved_at AS resolvedat,resolved_by AS resolvedby",[decodeURIComponent(p[2]),status,me.username]);if(!a[0])return reply({error:'Approval not found or already resolved'},404);await audit(db,me,'APPROVAL_'+status.toUpperCase(),a[0].action+' · '+a[0].description,request);const x2=a[0];return reply({ok:true,approval:{id:x2.id,action:x2.action,description:x2.description,status:x2.status,requestedBy:x2.requestedby,createdAt:x2.createdat,resolvedAt:x2.resolvedat,resolvedBy:x2.resolvedby}})}
  if(u.pathname==='/api/auth/change-password'&&request.method==='POST'){
   const x=await readBody(request,16384),current=String(x.currentPassword||''),next=String(x.newPassword||'');
   if(!current||current.length>1024)return reply({error:'Enter your current password (at most 1,024 characters).',code:'PASSWORD_CURRENT_INVALID'},400);
   if(next.length<12||next.length>1024||!/[A-Za-z]/.test(next)||!/[0-9]/.test(next))return reply({error:'New password must be 12–1,024 characters and include letters and numbers',code:'PASSWORD_INVALID'},400);
   if(equal(current,next))return reply({error:'Choose a new password different from your current password.',code:'PASSWORD_UNCHANGED'},400);
   if(typeof db.transaction!=='function')return reply({error:'Password changes are temporarily unavailable.',code:'PASSWORD_CHANGE_UNAVAILABLE'},503);
   // An authenticated session must not become an unlimited current-password
   // guessing endpoint. Like sign-in, this counter is independent of audit.
   let permitted=false;
   try{permitted=await consumeRateLimit(db,'password-change',me.id,5,300)}catch{return reply({error:'Password changes are temporarily unavailable.',code:'PASSWORD_CHANGE_UNAVAILABLE'},503)}
   if(!permitted)return reply({error:'Too many password change attempts. Wait five minutes before trying again.',code:'PASSWORD_CHANGE_RATE_LIMIT'},429,{'Retry-After':'300'});
   const row=await db.query('SELECT salt,password_hash FROM app_users WHERE id=$1 AND active=true',[me.id]);
   if(!row[0]||!equal(await pass(current,row[0].salt),row[0].password_hash))return reply({error:'Current password is incorrect',code:'PASSWORD_CURRENT_INVALID'},401);
   // The account update and revocation must either both commit or neither do.
   // Recheck the requesting session as well as the verified password. This
   // rejects a revocation committed before this statement's snapshot, but it
   // does not cancel requests already executing concurrently with revocation.
   // A fresh READ COMMITTED snapshot for the second statement also catches a
   // login that held the account lock when this update began. Test adapters
   // without the same non-interactive transaction capability fail closed.
   const salt=hex(random(16)),hash=await pass(next,salt);
   const result=await db.transaction(tx=>[
    tx.query(`UPDATE app_users SET salt=$1,password_hash=$2,updated_at=now()
      WHERE id=$3 AND active=true AND salt=$4 AND password_hash=$5
        AND EXISTS (SELECT 1 FROM sessions WHERE id=$6 AND user_id=$3 AND revoked_at IS NULL AND expires_at>now())
      RETURNING id,salt,password_hash`,
      [salt,hash,me.id,row[0].salt,row[0].password_hash,me.session_id]),
    tx.query(`UPDATE sessions SET revoked_at=now()
      WHERE user_id=$1 AND id<>$2 AND revoked_at IS NULL
        AND EXISTS (SELECT 1 FROM app_users WHERE id=$1 AND active=true AND salt=$3 AND password_hash=$4)
      RETURNING id`,[me.id,me.session_id,salt,hash])
   ],{isolationLevel:'ReadCommitted'});
   if(!Array.isArray(result)||result.length!==2||!Array.isArray(result[0])||!Array.isArray(result[1]))throw Error('Password change result could not be confirmed');
   const changed=result[0];
   if(!changed.length&&!result[1].length)return reply({error:'Your session, account or password changed during this request. Check your session and use the latest password before trying again.',code:'PASSWORD_CHANGE_STALE'},409);
   if(changed.length!==1||changed[0].id!==me.id||changed[0].salt!==salt||changed[0].password_hash!==hash)throw Error('Password change result could not be confirmed');
   await audit(db,me,'PASSWORD_CHANGED','Password changed; other sessions revoked',request);return reply({ok:true,otherSessionsRevoked:true});
  }
  if(u.pathname==='/api/admin/users'&&['GET','POST'].includes(request.method)){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   if(request.method==='GET'){const rows=await db.query('SELECT id,username,role,active,created_at FROM app_users ORDER BY created_at DESC LIMIT 500');return reply({users:rows.map(x=>({id:x.id,username:x.username,role:x.role,active:x.active,createdAt:x.created_at}))})}
   const x=await readBody(request),inputName=String(x.username||'').trim(),password=String(x.password||''),role=String(x.role||'Viewer');
   if(!/^[A-Za-z0-9_.-]{3,40}$/.test(inputName))return reply({error:'Username must be 3–40 safe characters'},400);
   if(password.length<12||password.length>1024||!/[A-Za-z]/.test(password)||!/[0-9]/.test(password))return reply({error:'Password must be at least 12 characters and include letters and numbers'},400);
   if(!['Admin','Manager','Data Operator','Viewer'].includes(role))return reply({error:'Invalid role'},400);
   const username=inputName.toLowerCase();
   if(await usernameExists(db,username))return reply({error:'Username already exists'},409);
   const salt=hex(random(16)),id=crypto.randomUUID();
   try{await db.query('INSERT INTO app_users(id,username,role,salt,password_hash) VALUES($1,$2,$3,$4,$5)',[id,username,role,salt,await pass(password,salt)])}catch(e){if(e?.code==='23505'||/unique|duplicate/i.test(String(e?.message||'')))return reply({error:'Username already exists'},409);throw e}
   await audit(db,me,'ADMIN_USER_CREATE',username+' · '+role,request);return reply({user:{id,username,role,active:true,createdAt:new Date().toISOString()}},201);
  }
  if(p[1]==='admin'&&p[2]==='users'&&p.length===4&&request.method==='PATCH'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   let id;try{id=decodeURIComponent(p[3]).toLowerCase()}catch{return reply({error:'Invalid user ID',code:'USER_STATUS_INVALID'},400)}
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id))return reply({error:'Invalid user ID',code:'USER_STATUS_INVALID'},400);
   const x=await readBody(request);if(typeof x.active!=='boolean')return reply({error:'active must be true or false',code:'USER_STATUS_INVALID'},400);
   if(id===String(me.id).toLowerCase()&&!x.active)return reply({error:'You cannot deactivate your own account',code:'USER_STATUS_SELF'},400);
   if(typeof db.transaction!=='function')return reply({error:'User status changes are temporarily unavailable.',code:'USER_STATUS_UNAVAILABLE'},503);
   // Serialize all status transitions, then lock the actor and session before
   // rechecking them. Two preauthenticated Admins cannot deactivate each other.
   // The target lock is a separate statement: a login which committed while we
   // waited is visible to the following READ COMMITTED statement. The status
   // update and its dependent session revocation then succeed or roll back as
   // one statement. Reactivation also clears legacy unrevoked sessions left by
   // older partial failures; repeating activation of an active user does not.
   const result=await db.transaction(tx=>[
    tx.query('SELECT pg_advisory_xact_lock(1095394156,1)'),
    tx.query('SELECT id FROM app_users WHERE id=$1 FOR SHARE',[me.id]),
    tx.query('SELECT id FROM sessions WHERE id=$1 AND user_id=$2 FOR SHARE',[me.session_id,me.id]),
    tx.query('SELECT id FROM app_users WHERE id=$1 FOR UPDATE',[id]),
    tx.query(`WITH prior AS MATERIALIZED (
      SELECT id,role,active FROM app_users WHERE id=$1
     ), authorized AS MATERIALIZED (
      SELECT u.id FROM app_users u JOIN sessions s ON s.user_id=u.id
      WHERE u.id=$3 AND u.active=true AND u.role='Admin' AND s.id=$4
        AND s.revoked_at IS NULL AND s.expires_at>statement_timestamp()
     ), changed AS (
      UPDATE app_users AS target SET active=$2::boolean,updated_at=now() FROM prior
      WHERE target.id=prior.id AND EXISTS (SELECT 1 FROM authorized)
        AND ($2::boolean OR NOT prior.active OR prior.role<>'Admin'
          OR (SELECT count(*) FROM app_users WHERE role='Admin' AND active=true)>1)
      RETURNING target.id,target.username,target.role,target.active,target.created_at,prior.active AS was_active
     ), revoked AS (
      UPDATE sessions SET revoked_at=now() WHERE revoked_at IS NULL
        AND user_id IN (SELECT id FROM changed WHERE NOT $2::boolean OR NOT was_active)
      RETURNING id
     )
     SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM authorized) THEN 'stale'
       WHEN NOT EXISTS (SELECT 1 FROM prior) THEN 'missing'
       WHEN EXISTS (SELECT 1 FROM changed) THEN 'updated'
       WHEN NOT $2::boolean AND EXISTS (SELECT 1 FROM prior WHERE role='Admin' AND active=true)
         AND (SELECT count(*) FROM app_users WHERE role='Admin' AND active=true)<=1 THEN 'last_admin'
       ELSE 'not_updated' END AS outcome,
       changed.id,changed.username,changed.role,changed.active,changed.created_at,changed.was_active,
       (SELECT count(*)::int FROM revoked) AS revoked_count
     FROM (SELECT 1) singleton LEFT JOIN changed ON true`,[id,x.active,me.id,me.session_id])
   ],{isolationLevel:'ReadCommitted'});
   if(!Array.isArray(result)||result.length!==5||result.some(rows=>!Array.isArray(rows))||result[4].length!==1)throw Error('User status result could not be confirmed');
   const z=result[4][0];
   if(z.outcome==='stale')return reply({error:'Your Administrator session or account changed. Sign in again and refresh before retrying.',code:'ADMIN_SESSION_STALE'},409);
   if(z.outcome==='missing')return reply({error:'User not found',code:'USER_STATUS_NOT_FOUND'},404);
   if(z.outcome==='last_admin')return reply({error:'Cannot deactivate the last active administrator',code:'USER_STATUS_LAST_ADMIN'},409);
   if(z.outcome==='not_updated')return reply({error:'User status was not changed. Refresh before retrying.',code:'USER_STATUS_CONFLICT'},409);
   if(z.outcome!=='updated'||String(z.id).toLowerCase()!==id||z.active!==x.active||typeof z.was_active!=='boolean'||typeof z.username!=='string'||typeof z.role!=='string'||!z.created_at||!Number.isInteger(Number(z.revoked_count))||Number(z.revoked_count)<0)throw Error('User status result could not be confirmed');
   await audit(db,me,'ADMIN_USER_STATUS',z.username+' · '+(x.active?'activated':'deactivated'),request);
   return reply({user:{id:z.id,username:z.username,role:z.role,active:z.active,createdAt:z.created_at},sessionsRevoked:!x.active||!z.was_active,revokedSessions:Number(z.revoked_count)});
  }
  if(u.pathname==='/api/records/bulk'&&request.method==='POST'){
   if(!WRITERS.includes(me.role))return reply({error:'Role not permitted'},403);
   const x=await readBody(request),input=x.records;
   if(!Array.isArray(input))return reply({error:'Records must be an array'},400);
   if(input.length>MAX_BATCH_RECORDS)return reply({error:'Import batch exceeds 5,000 records'},413);
   if(!input.length)return reply({inserted:0,updated:0,skipped:0,skippedDeleted:0});
   let rows;try{rows=normalizeRecords(input)}catch(e){return reply({error:e.message},400)}
   const ids=new Set(rows.map(r=>r.id).filter(Boolean));
   for(const row of rows)if(!row.id){let id;do{id='AJ-'+crypto.randomUUID().toUpperCase()}while(ids.has(id));row.id=id;ids.add(id)}
   const values=[],tuples=rows.map(row=>{const a=[row.id,row.name,row.region,row.sector,row.status,row.notes],n=values.length;values.push(...a);return '('+a.map((_,j)=>'$'+(n+j+1)).join(',')+')'});
   // Data Operators can import but cannot delete. A conflicting deleted row
   // must never be revived implicitly through the upsert path.
   const saved=await db.query('INSERT INTO records(id,name,region,sector,status,notes,created_by,updated_by) SELECT v.id,v.name,v.region,v.sector,v.status,v.notes,$'+(values.length+1)+',$'+(values.length+1)+' FROM (VALUES '+tuples.join(',')+') AS v(id,name,region,sector,status,notes) ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,region=EXCLUDED.region,sector=EXCLUDED.sector,status=EXCLUDED.status,notes=EXCLUDED.notes,updated_by=$'+(values.length+1)+',updated_at=now() WHERE records.deleted_at IS NULL RETURNING (xmax=0) AS inserted',[...values,me.id]);
   const inserted=saved.filter(z=>z.inserted).length,updated=saved.length-inserted,skippedDeleted=rows.length-saved.length;
   await audit(db,me,'BULK_IMPORT','Inserted '+inserted+'; updated '+updated+'; skipped deleted '+skippedDeleted,request);return reply({inserted,updated,skipped:skippedDeleted,skippedDeleted});
  }
  if(u.pathname==='/api/backup'&&request.method==='GET'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   const rows=await db.query('SELECT id,name,region,sector,status,notes,updated_at AS "updatedAt" FROM records WHERE deleted_at IS NULL ORDER BY id');
   await audit(db,me,'BACKUP_EXPORT','Exported '+rows.length+' active records',request);return reply({format:'alsyed-jalal-backup',version:1,exportedAt:new Date().toISOString(),records:rows});
  }
  if(u.pathname==='/api/restore'&&request.method==='POST'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);
   const x=await readBody(request),input=x.records;
   if(x.format!=='alsyed-jalal-backup'||x.version!==1||!Array.isArray(input)||!input.length)return reply({error:'A version 1 Al-Syed Jalal records export with records is required'},400);
   if(input.length>MAX_BATCH_RECORDS)return reply({error:'Restore is limited to 5,000 records per request'},413);
   if(x.restoreDeleted!==undefined&&typeof x.restoreDeleted!=='boolean')return reply({error:'restoreDeleted must be true or false'},400);
   const restoreDeleted=x.restoreDeleted===true;
   if(restoreDeleted&&x.confirm!=='restore-deleted-records')return reply({error:'Explicit confirmation is required to restore deleted records'},400);
   let rows;try{rows=normalizeRecords(input,{requireId:true})}catch(e){return reply({error:e.message},400)}
   const values=[],tuples=rows.map(row=>{const a=[row.id,row.name,row.region,row.sector,row.status,row.notes],n=values.length;values.push(...a);return '('+a.map((_,j)=>'$'+(n+j+1)).join(',')+')'});
   const deletionUpdate=restoreDeleted?',deleted_at=NULL,deleted_by=NULL':'',conflictScope=restoreDeleted?'':' WHERE records.deleted_at IS NULL';
   const saved=await db.query('INSERT INTO records(id,name,region,sector,status,notes,created_by,updated_by) SELECT v.id,v.name,v.region,v.sector,v.status,v.notes,$'+(values.length+1)+',$'+(values.length+1)+' FROM (VALUES '+tuples.join(',')+') AS v(id,name,region,sector,status,notes) ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,region=EXCLUDED.region,sector=EXCLUDED.sector,status=EXCLUDED.status,notes=EXCLUDED.notes,updated_by=$'+(values.length+1)+',updated_at=now()'+deletionUpdate+conflictScope+' RETURNING id',[...values,me.id]);
   const skippedDeleted=rows.length-saved.length;
   await audit(db,me,'BACKUP_RESTORE','Merged '+saved.length+' records; skipped deleted '+skippedDeleted+'; include deleted '+restoreDeleted+'; no unrelated records deleted',request);
   return reply({ok:true,restoredRecords:saved.length,skippedDeleted,restoreDeleted,mode:'merge'});
  }
  if(u.pathname==='/api/security/events'&&request.method==='GET'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);const rows=await db.query('SELECT e.action,e.detail,e.created_at,u.username FROM audit_events e LEFT JOIN app_users u ON u.id=e.user_id ORDER BY e.created_at DESC LIMIT 100');return reply({events:rows.map(z=>({action:z.action,detail:z.detail,user:z.username||'system',time:z.created_at}))});
  }
  if(u.pathname==='/api/admin/permissions'&&request.method==='GET'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);return reply({permissions:{Admin:['all permissions','user management','backup and restore','system diagnostics'],Manager:['read records','create and update records','soft-delete records','resolve approvals'], 'Data Operator':['read records','create and update records','bulk import'],Viewer:['read records','view dashboards']}});
  }
  if(u.pathname==='/api/admin/metrics'&&request.method==='GET'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);const [runs,events,sessions]=await Promise.all([db.query("SELECT count(*)::int AS requests,count(*) FILTER(WHERE status<>'completed')::int AS errors FROM ai_runs WHERE created_at>now()-interval '24 hours'"),db.query("SELECT count(*)::int AS n FROM audit_events WHERE created_at>now()-interval '24 hours' AND action LIKE '%RATE_LIMIT%'"),db.query('SELECT count(*)::int AS n FROM sessions WHERE revoked_at IS NULL AND expires_at>now()')]);return reply({process:{uptimeSeconds:null,metric:'not exposed by stateless Pages runtime'},requests:{requests:Number(runs[0]?.requests||0),errors:Number(runs[0]?.errors||0),rateLimited:Number(events[0]?.n||0),scope:'AI runs and recorded rate-limit events, last 24h'},db:{connections:null,max_connections:null,activeSessions:Number(sessions[0]?.n||0)}});
  }
  if(u.pathname==='/api/admin/data-integrity'&&request.method==='GET'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);const [a,b,c,d]=await Promise.all([db.query("SELECT count(*)::int AS n FROM records WHERE deleted_at IS NULL AND btrim(name)=''"),db.query('SELECT count(*)::int AS n FROM record_history h LEFT JOIN records r ON r.id=h.record_id WHERE r.id IS NULL'),db.query('SELECT count(*)::int AS n FROM documents d LEFT JOIN records r ON r.id=d.record_id WHERE d.record_id IS NOT NULL AND r.id IS NULL AND d.deleted_at IS NULL'),db.query('SELECT count(*)::int AS n FROM (SELECT lower(username) FROM app_users GROUP BY lower(username) HAVING count(*)>1) q')]);const checks={recordsMissingName:Number(a[0]?.n||0),orphanHistory:Number(b[0]?.n||0),orphanDocuments:Number(c[0]?.n||0),duplicateUsernames:Number(d[0]?.n||0)};return reply({ok:Object.values(checks).every(v=>v===0),status:Object.values(checks).every(v=>v===0)?'clean':'issues_found',checks});
  }
  if(u.pathname==='/api/admin/system-snapshot'&&request.method==='GET'){
   if(me.role!=='Admin')return reply({error:'Admin role required'},403);const [r,d,s,a,ai,reg,sec]=await Promise.all([db.query('SELECT count(*) FILTER(WHERE deleted_at IS NULL)::int AS active,count(*) FILTER(WHERE deleted_at IS NOT NULL)::int AS deleted FROM records'),db.query('SELECT count(*)::int AS n FROM documents WHERE deleted_at IS NULL'),db.query('SELECT count(*)::int AS n FROM sessions WHERE revoked_at IS NULL AND expires_at>now()'),db.query("SELECT count(*)::int AS n FROM audit_events WHERE created_at>now()-interval '24 hours'"),db.query("SELECT count(*)::int AS n FROM ai_runs WHERE status='running' AND created_at>now()-interval '10 minutes'"),db.query("SELECT region,count(*)::int AS count FROM records WHERE deleted_at IS NULL GROUP BY region ORDER BY count DESC LIMIT 8"),db.query("SELECT sector,count(*)::int AS count FROM records WHERE deleted_at IS NULL GROUP BY sector ORDER BY count DESC LIMIT 8")]);return reply({records:{active:Number(r[0]?.active||0),deleted:Number(r[0]?.deleted||0)},documents:Number(d[0]?.n||0),sessions:{active:Number(s[0]?.n||0)},audit24h:{total:Number(a[0]?.n||0)},ai:{active:Number(ai[0]?.n||0),maxConcurrent:null,queued:null},pool:{total:null,idle:null,waiting:null,source:'Neon connection pool metrics are not exposed to this Pages Function'},process:{uptimeSeconds:null,source:'stateless edge runtime'},regions:reg.map(z=>({region:z.region,count:Number(z.count)})),sectors:sec.map(z=>({sector:z.sector,count:Number(z.count)}))});
  }
  if(u.pathname==='/api/ai/supervisor'&&request.method==='POST'){
   const x=await readBody(request),goal=String(x.goal||'').trim(),max=Math.min(3,Math.max(1,Number(x.maxTasks)||3)),childHeaders=new Headers(request.headers);childHeaders.delete('content-length');childHeaders.set('content-type','application/json');if(goal.length<2||goal.length>5000)return reply({error:'Goal must be 2–5,000 characters'},400);const roles=['analysis','research','coding'].slice(0,max),results=[];for(let i=0;i<roles.length;i++){const task='Supervisor task '+(i+1)+' ('+roles[i]+'): '+goal+'\nProvide only this specialist perspective, key findings and actionable next step.';const target=new URL(request.url);target.pathname='/api/ai/run';const rr=await onRequest({request:new Request(target,{method:'POST',headers:childHeaders,body:JSON.stringify({prompt:task,provider:x.provider||'gemini',agentId:roles[i]})}),env});const data=await rr.json();results.push({agentId:roles[i],status:rr.ok?'completed':'failed',output:data.output||'',error:data.error||null,traceId:data.traceId||null});if(!rr.ok)break}return reply({status:results.every(z=>z.status==='completed')?'completed':'partial',summary:results.map(z=>z.output).filter(Boolean).join('\n\n'),results});
  }
  if(u.pathname==='/api/ai/autogpt'&&request.method==='POST'){
   const x=await readBody(request),goal=String(x.goal||'').trim(),max=Math.min(3,Math.max(1,Number(x.maxIterations)||3)),childHeaders=new Headers(request.headers);childHeaders.delete('content-length');childHeaders.set('content-type','application/json');if(goal.length<2||goal.length>5000)return reply({error:'Goal must be 2–5,000 characters'},400);const steps=[];let context='';for(let i=1;i<=max;i++){const prompt='Bounded AutoGPT planning iteration '+i+' of '+max+'. Goal: '+goal+'\nPrevious iteration: '+context.slice(0,3500)+'\nReturn the next concrete plan/refinement. Do not claim external tools or actions were executed.';const target=new URL(request.url);target.pathname='/api/ai/run';const rr=await onRequest({request:new Request(target,{method:'POST',headers:childHeaders,body:JSON.stringify({prompt,provider:x.provider||'gemini',agentId:x.agentId||'autogpt'})}),env});const data=await rr.json();steps.push({iteration:i,status:rr.ok?'completed':'failed',output:data.output||'',error:data.error||null,traceId:data.traceId||null});if(!rr.ok)break;context=data.output||''}return reply({status:steps.every(z=>z.status==='completed')?'completed':'partial',iteration:steps.length,steps});
  }
  return reply({ok:false,error:'Route not yet migrated to Cloudflare API',code:'ROUTE_NOT_IMPLEMENTED'},501)
 }catch(e){const status=Number(e?.status)||500;
  // Hide internals in production, but never hide them from the local preview —
  // a bare "Internal server error" made a real failure undiagnosable.
  const detail=env.LOCAL_PREVIEW?String(e?.message||e).slice(0,300):undefined;
  return reply({ok:false,error:status>=500?'Internal server error':e.message,code:status===500?'INTERNAL_ERROR':'REQUEST_ERROR',...(detail?{detail}:{})},status)}
}
