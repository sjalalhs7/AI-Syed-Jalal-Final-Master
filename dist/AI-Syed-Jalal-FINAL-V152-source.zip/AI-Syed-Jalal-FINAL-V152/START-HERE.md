# AI-Syed Jalal — final application, V152 (SJS brand)

This folder is the complete application, including the new **SJS** identity.
Two ways to run it, plus the website bundle. Nothing here needs a paid service
to start.

---

## 1. Run the real application (backend + database + AI tools)

Requires Node.js 22.13 or newer. No database server to install: the app ships a
local PostgreSQL-compatible engine (PGlite).

```bash
cd AI-Syed-Jalal-FINAL-V152/source/AI-Syed-Jalal-FINAL-RECOVERED
npm ci                      # once
npm run dev                 # http://localhost:3000
```

Then open **http://localhost:3000/guide.html** — the front door — and press
**Try the local preview**. That creates a disposable account so you can use every
surface immediately.

What works with **no API key at all**: JalalAi chat and local tools, calculator,
tasks, notes, Quick Notes, Toolbench (13 deterministic tools), Page Builder,
Arena structure and prompt library, Agent Lab self-check, Workspace records,
documents, printing, the dashboard, roadmaps, and every OS-integration surface.

What needs a **server-side provider key** (OpenAI, Anthropic, Gemini or
DeepSeek): open-ended cloud answers. Put the key in your host's secret settings
or a local `.env` — never in the frontend:

```bash
GEMINI_API_KEY=...          # or OPENAI_API_KEY / ANTHROPIC_API_KEY / DEEPSEEK_API_KEY
CSRF_SECRET=<32+ random characters>
```

The app states plainly when a provider is not configured. It never pretends a
model answered.

### First run, in order

1. `npm run dev`, open `/guide.html`, press **Try the local preview**.
2. Open `/capabilities.html` to see which of the ten OS integrations your
   browser supports right now.
3. Install the app (browser install icon) and try a shortcut: right-click the
   icon → **New note**.
4. For real accounts, create the first Administrator: `/api/bootstrap/status`
   says whether that is still available (it closes once one exists).

### Where data lives

| What | Where |
| --- | --- |
| Local database | `.data/postgres/` |
| Session secret | `.data/session-secret` (created on first run, mode 0600) |
| Playwright test database | `.data/e2e/` (disposable) |

Back up `.data/` to keep your local data. To start clean, stop the server and
delete `.data/`.

---

## 2. The SJS brand

Everything lives in `frontend/assets/brand/` and `frontend/assets/app-icons/`.

| File | Use |
| --- | --- |
| `brand/sjs-logo.svg` | Primary mark — headers, app icon, sign-in screen |
| `brand/sjs-mark.svg` | Same mark without the tile, for your own backgrounds |
| `brand/sjs-maskable.svg` | Android maskable icon (art inside the 80% safe circle) |
| `brand/sjs-compact.svg` | Simplified cut for 16–48 px (no orbits — they turn to noise) |
| `brand/sjs-mono.svg` | One-colour cut for print, embroidery, faxes and stamping |
| `brand/favicon.svg` | Browser tab icon |
| `brand/sjs-og-1200x630.png` | Social share card (Open Graph / Twitter) |
| `app-icons/*.png` | 16 / 32 / 48 / 180 / 192 / 512 / maskable tiles |

The mark is gold → orange → emerald on the approved deep navy. The letters are
real Montserrat Black outlines, not hand-drawn paths, so they stay typographically
correct at any size. Below 48 px the orbits are dropped on purpose — that
simplification is what keeps the favicon legible.

If you change the icon artwork, bump this line in `frontend/sw.js` so installed
apps refresh their cached logo:

```js
const CACHE='aj-v152-shell';
```

---

## 3. Put the website online

### Option A — Cloudflare Pages (full application: login, database, saved data)

```bash
npm i -g wrangler
wrangler pages project create ai-syed-jalal-live
wrangler pages deploy frontend --project-name ai-syed-jalal-live
```

Then set these in the Cloudflare dashboard (Settings → Environment variables /
Secrets), never in a file you commit:

- `DATABASE_URL` — a Neon PostgreSQL connection string
- `CSRF_SECRET` — 32+ random characters
- `GEMINI_API_KEY` / `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` / `DEEPSEEK_API_KEY`

Apply the schema once against that database:

```bash
DATABASE_URL="postgres://..." npm run db:migrate
```

Open `/api/ready` afterwards. It must say **23 of 23 tables present**. If it
lists missing tables, sign in as an Admin and run **Repair schema** in the
Workspace Operations panel, or re-run the migration.

### Option B — any static host (website only, no login or cloud AI)

Use `AI-Syed-Jalal-Website-V152-SJS-static.zip`. Unzip it into your host's web
root (GitHub Pages, Netlify, S3, Nginx, Cloudflare Pages…). `index.html` must
stay at the root.

This copy is honest about its limits: every page that needs the API detects the
static host and shows a banner with a link to setup, instead of hanging or
showing a raw error. **The OS integration still works on a static host** —
installation, caching, shortcuts and Quick Notes are client-side. Only sign-in,
saved data and cloud AI need the backend.

---

## 4. Verify it yourself

The release gates ship with the source, so you are not trusting a document.

```bash
npm test                 # server + frontend contracts
npm run check            # 51 static checks
npm run test:browser     # 50 real browser journeys (needs no network)
```

Expected at V152: **148 server · 80 frontend · 51 static · 50 browser**, all
green, plus `23 of 23` schema tables from an empty database.

---

## 5. What is finished, and what is not

Finished and tested:

- The whole application above, from an empty database.
- All ten OS integrations, probed live on `/capabilities.html`.
- The SJS identity across all 24 pages, the manifest, the favicons and the
  social card, with a test that fails the build if a page falls off-brand.
- Service worker install, offline page serving, and cache rules that keep
  private content out of Cache Storage.
- Manifest validated with Chromium's own parser: 0 errors, 0 installability
  errors.

**Not proven here** — stated so nobody has to discover it later:

- Windows 11 widgets, ChromeOS tab strips, ChromeOS note taking and the Edge
  side panel were **not run on those operating systems**. No such device was
  available. The declarations are spec-correct and the service worker handles
  every widget event, but "shipped" for those four means implemented and tested
  where a browser could be tested.
- Live provider calls, live Google Search grounding, production load and
  penetration testing, and physical-device voice testing.
- `worker/index.js` is a **gateway stub**: it returns a clear 503 until
  `BACKEND_API_URL` is set. The real API is the Pages Functions code in
  `frontend/functions/`, which is what the Cloudflare Pages deployment uses.
