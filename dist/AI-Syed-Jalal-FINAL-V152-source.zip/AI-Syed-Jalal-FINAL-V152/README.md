# AI-Syed-Jalal — Reconciled Recovery Master

This repository contains the unified AI-Syed Jalal platform on `main`: the recovered source lineage, the repaired runnable application, and **SJ Agent Studio** (`/agent.html`). Historical recovery archives are preserved unchanged and are also available in the published `v1.0.0` GitHub Release.

## Locked design rule
The approved Login Page + Homepage + Logo identity, theme language, and hierarchy are locked. Add capabilities without unnecessary redesign. Older concept boards remain historical references, not replacements for the approved design.

## Quick links

The runnable application lives in `source/AI-Syed-Jalal-FINAL-RECOVERED/`:

- `/allinone.html` — one request, every specialist that can serve it, each answer labelled with why.
- `/toolbench.html` — the agent's deterministic tools by hand (dates, units, JSON, hashes, WCAG contrast, CSV, code audit, diff, page builder).
- `/pagebuilder.html` — one sentence in, a complete single-file HTML page out; sandboxed preview, self-audit, real download.
- `/arena.html` — blind battles, a prompt library with checkable properties, portable export.
- `/critic.html` — the graded review of this deployment, from stored evidence.
- `/guide.html` — **the front door**: one-click preview, live status, and a map of every surface.
- `/capabilities.html` — a live probe of the ten OS integrations (shortcuts, file handlers, launch handler, protocol handlers, share target, widgets, side panel, window controls overlay, tabbed display, note taking) on the device you are using.
- `/notes.html` — Quick Notes: the destination for the app shortcut, the OS widget, the note-taking entry and handled `.txt`/`.md` files.

Release notes: `V151-PWA-CAPABILITIES-2026-11-07.md` (OS integration) · `V142-FINAL-2026-11-05.md` (final handoff) · `V141-PAGE-BUILDER-2026-11-05.md` · `V140-ARENA-TOOLBOX-2026-11-04.md`. Gates: 51 static · 142 server · 80 frontend · 50 browser · self-check 100/100 · 23 tables from an empty database.

## Source lineage
- V122-MERGED is the larger recovered source base: 9,950 files and 282,418,696 bytes uncompressed in its original archive.
- V125-FULL is a smaller curated continuation: 1,226 files and 18,719,357 bytes uncompressed. It is not a complete replacement for V122.
- The recovery master combines the V122 source lineage with selected V125 additions and verified engineering-baseline records.
- The original historical V25 archive remains missing/unverified.

## Main user-facing surfaces in the recovery package
- Public homepage and login entry
- Dashboard and workspace shell
- AI command console and agent catalog
- Google Gemini / AI Studio provider adapter and optional Google Search grounding configuration
- Bounded Supervisor and AutoGPT UI/API contracts
- Skills/catalog, Agency profiles/tools, learning roadmaps and OSSU reference material
- Profile/settings and OpenCode/Android IDE integration contracts

## Verification summary
Offline regression/source gates pass for the V76/V73/V75 lineage, 3,500 skills across 35 domains, 120 catalog roles, 303 Agency profiles, 16 Agency tool targets, bounded Supervisor/AutoGPT logic, roadmap data/page/menu, source audit, upstream references, and palette contract.

Local PostgreSQL-compatible integration and Chromium browser journeys now pass. Not yet proven as live production: owner-controlled Neon/Cloudflare staging, real provider calls, live Google Search grounding, physical device/voice tests, production load/penetration tests, and exact V25 lineage recovery. Source presence or UI controls are not proof of live integration.

See:
- `docs/FINALIZATION-STATUS.md`
- `docs/AGENT-CAPABILITY-ROADMAP.md`
- `docs/RELEASE-ASSET-HANDOFF.md`
- `docs/visual-history/` in the full recovery package

## Security
Provider secrets stay server-side. Do not commit API keys or production credentials. Medical features must be educational, source-grounded, and safety-gated. Microphone/camera/screen capabilities must be opt-in, permission-gated, visibly active, and revocable.

## Website and login status

- **GitHub Pages website:** https://sjalalhs7.github.io/AI-Syed-Jalal-Final-Master/ opens the static frontend. `.github/workflows/pages.yml` publishes `source/AI-Syed-Jalal-FINAL-RECOVERED/frontend` when the repository Pages source is set to GitHub Actions; the root `index.html` also provides a legacy-Pages launcher to the same frontend.
- **Important:** GitHub Pages is static hosting. It can display the login page and public guides, but it cannot run the login API, database, saved conversations or server-side AI. The site detects this and shows setup guidance instead of pretending sign-in succeeded.
- **Full application:** use the secure Cloudflare Pages + Neon deployment, or run locally from `source/AI-Syed-Jalal-FINAL-RECOVERED` with `npm ci` and `npm run dev`, then open `/guide.html`.
- Production sign-in still requires owner-controlled `DATABASE_URL`, `CSRF_SECRET`, applied migrations and provider keys. No credentials are stored in this repository.

## Runnable application and quick start (November 2026)

The repaired application is tracked under [`source/AI-Syed-Jalal-FINAL-RECOVERED/`](source/AI-Syed-Jalal-FINAL-RECOVERED/). From that directory run `npm ci` and `npm run dev`, then open `/guide.html` for one-click preview access, live capability status and a plain-language guide. `/jalalai.html` is the assistant; `/workspace.html` is the workspace; `/dashboard.html` is the profile/skills dashboard; `/agent-lab.html` runs the graded self-check and the skill library; `/arena.html` runs blind multi-engine battles with a rubric judge and a per-account leaderboard.

Use test data only in the local preview. See the [application status and verification report](source/AI-Syed-Jalal-FINAL-RECOVERED/APPLICATION-STATUS.md) for working features, test evidence, limitations and production release gates. The original recovery archives remain unchanged.

## Final handoff

Start with **[FINAL-HANDOFF-V135.md](FINAL-HANDOFF-V135.md)** — one page covering every working surface,
the one-command proof, the exact gate results, what is deliberately not built, and the owner-only steps
that remain.

## V138 — Expert Critic and the merged architecture (4 November 2026)

Arena, JalalAi, JARVIS and Agent Studio are merged at the runtime, voice and evidence layers, and the
decisions — including two duplications that deliberately remain — are published at
`/refactor-plan.html`. **`/critic.html`** grades the deployment across seven dimensions from stored
evidence: no evidence scores zero, one blocker forbids a "ready" verdict, and every finding carries its
evidence and its fix. On a used preview it reported **ready, 97/100**; on an empty one, **not-ready,
39/100**. Readiness now requires **21** tables. See
[V138-EXPERT-CRITIC-2026-11-04.md](V138-EXPERT-CRITIC-2026-11-04.md).

## V137 — JARVIS voice console (4 November 2026)

**JARVIS** (`jarvis.html`) is a hands-free voice front end for the same bounded agent runtime:
**Hold to talk**, optional auto-run on the final transcript, hands-free reading of replies, a shared
browser voice + language, and a live tool trace for every command. The voice surface contract lives in
`frontend/functions/voice-surfaces.mjs` and is graded by the self-check (`voice.surfaces`, 19 checks
total), three static checks and three browser journeys that assert what was actually spoken.
See [V137-JARVIS-VOICE-2026-11-04.md](V137-JARVIS-VOICE-2026-11-04.md).

## V136 — real agent runtime (4 November 2026)

JalalAi gained **Agent mode**: a bounded, four-tool runtime (`calculator`, live `Wikipedia research`,
`records`, `tasks`) that renders an **agent trace** — every step with its tool, duration and real output,
and `FAILED` when a tool could not run. Runs are stored in `agent_runs` and readable at
`/api/assistant/agent/runs`. Readiness now requires **20** tables; the self-check runs 18 checks.
See [V136-AGENT-RUNTIME-2026-11-04.md](V136-AGENT-RUNTIME-2026-11-04.md).

## V135 — SJ Arena, the Arena.ai-style battle clone (4 November 2026)

`/arena.html` runs **2–4 engines on one prompt**, hides which engine wrote which answer until you vote,
scores every answer with the deterministic `sj-rubric-v1` judge (structure, specificity, coverage,
honesty, code) and shows the sub-scores, then records your vote as the decision. Local engines run
in-process through the same `localAssistant` the platform uses; cloud engines go through the real
`/api/ai/run` route and are stored as **not configured** — zero, labelled, never a tie — when no key
exists. Ratings (start 1200, ±12 per decided battle) build a per-account leaderboard, and fenced code is
extracted into sandboxed HTML/SVG previews. Migration `011_v135_arena.sql` adds `arena_battles`,
`arena_responses`, `arena_artifacts` and `arena_ratings`; readiness now requires **19** tables.
See [V135-ARENA-2026-11-04.md](V135-ARENA-2026-11-04.md).

## V134 — working reply actions (4 November 2026)

Agent Studio's reply buttons now do real work: **Copy** saves the text as a new Direct turn with its own
answer, and **Regenerate** re-runs the same prompt on the same engine and *replaces* the stored reply
(compare pairs are swapped together). A failed generation keeps one flagged, retryable row instead of
losing the prompt. Agent Lab gained an **evidence CSV** export and **clickable skill cards** ("Use in
Studio" / "Critique with it") that stage a real prompt in Agent Studio, and its self-check grew to 16
checks. Migration `010_v134_message_actions.sql` adds `platform_messages.reply_to` and `.status`;
readiness went to 15 tables in V134 (19 since V135). See [V134-REPLY-ACTIONS-2026-11-04.md](V134-REPLY-ACTIONS-2026-11-04.md).

## V133 — Agent Lab (3 November 2026)

The newest application surface is **Agent Lab** (`source/AI-Syed-Jalal-FINAL-RECOVERED/frontend/agent-lab.html`).
One button runs a graded suite of 15 timeout-bounded checks against the live deployment — API health,
real database tables and round-trip writes, security boundaries (HttpOnly + CSRF), agent behaviour and
honesty labels, the 3,500-skill library and the page inventory — then stores the evidence per account and
plots the run history. The same page searches the skill library through `GET /api/agent/skills`.

Readiness now requires **15** tables (`agent_skills`, `agent_self_checks` added by migration
`009_v133_agent_skills.sql`). A passed run is deployment evidence, not a production certificate: cloud
providers, physical devices, load and compliance remain unproven and are labelled as such on the page.

See [V133-AGENT-LAB-UPDATE-2026-11-03.md](V133-AGENT-LAB-UPDATE-2026-11-03.md) for the change list,
test evidence and what is explicitly not claimed.

## Latest audit

[AUDIT-2026-11-03-EXPERT-LEVELUP.md](docs/AUDIT-2026-11-03-EXPERT-LEVELUP.md) continues from the
`85eeee7` premium-theme/voice-selector update: one shared browser-voice preference across JalalAi,
the Workspace dock, the Agent console and Agent Studio, removal of orphaned Workspace wiring, and a
hardened V129 quality gate. It also lists what remains owner-controlled.

## Final OK report

See [FINAL-OK-REPORT.md](FINAL-OK-REPORT.md) for the final handoff status, test evidence, package checksum and remaining production gates. [FINAL-VERIFICATION.md](FINAL-VERIFICATION.md) preserves the historical explanation of GitHub's 263 red deletion marks and the Worker gateway repair.


## Unified platform

SJ Agent Studio (`source/AI-Syed-Jalal-FINAL-RECOVERED/frontend/agent.html`) is the unified Arena-style workspace: Direct chat, bounded Agent workflows, side-by-side Compare, history, text/code attachments, voice and export. See `source/AI-Syed-Jalal-FINAL-RECOVERED/AGENT-STUDIO.md` and `PLATFORM-CONSOLIDATION.md`.
