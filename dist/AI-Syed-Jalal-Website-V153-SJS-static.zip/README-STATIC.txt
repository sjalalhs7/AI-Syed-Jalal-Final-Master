AI-Syed Jalal V153 - static website only

Extract into a static host's web root. This package deliberately disables
backend-dependent features: sign-in, saved data and cloud AI require the
separate V153 source application and a configured server/database.

This package cannot be converted to the full application merely by adding
keys. See START-HERE.md in the source archive for setup and limitations.
