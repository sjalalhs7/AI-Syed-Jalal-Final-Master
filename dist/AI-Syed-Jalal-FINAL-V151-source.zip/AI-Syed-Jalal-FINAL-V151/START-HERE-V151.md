# AI-Syed Jalal — final application, V151

This folder is the complete application. Two ways to run it, plus the website
bundle. Nothing here needs a paid service to start.

---

## 1. Run the real application (backend + database + AI tools)

Requires Node.js 22.13 or newer. No database server to install: the app ships a
local PostgreSQL-compatible engine (PGlite).

```bash
cd AI-Syed-Jalal-FINAL-V151
npm ci                      # once
npm run dev                 # http://localhost:3000
```

Then open **http://localhost:3000/guide.html** — the front door — and press
**Try the local preview**. That creates a disposable account so you can use every
surface immediately.

What works with **no API key at all**: JalalAi chat and local tools, calculator,
tasks, notes, Quick Notes, Toolbench (13 deterministic tools), Page Builder,
Arena structure and prompt library, Agent Lab self-check, Workspace records,
documents, printing, the dashboard, roadmaps, and every OS-integration surface
added in V151.

What needs a **server-side provider key** (OpenAI, Anthropic, Gemini or
DeepSeek): open-ended cloud answers. Put the key in your host's secret settings
or a local `.env` — never in the frontend:

```bash
GEMINI_API_KEY=...          # or OPENAI_API_KEY / ANTHROPIC_API_KEY / DEEPSEEK_API_KEY
CSRF_SECRET=<32+ random characters>
```

The app states plainly when a provider is not configured. It never pretends a
model answered.

### First run, in order

1. `npm run dev`, open `/guide.html`, press **Try the local preview**.
2. Open `/capabilities.html` to see which of the ten OS integrations your
   browser supports right now.
3. Install the app (browser install icon) and try a shortcut: right-click the
   icon → **New note**.
4. When you are ready for real accounts, open the bootstrap page and create the
   first Administrator: `/api/bootstrap/status` tells you whether that is still
   available (it closes permanently once one exists).

### Where data lives

| What | Where |
| --- | --- |
| Local database | `.data/postgres/` |
| Session secret | `.data/session-secret` (created on first run, mode 0600) |
| Playwright test database | `.data/e2e/` (disposable) |

Back up `.data/` to keep your local data. To start clean, stop the server and
delete `.data/`.

---

## 2. Put the website online

### Option A — Cloudflare Pages (full application: login, database, saved data)

The repository already contains the Pages Functions API and a `wrangler.jsonc`.

```bash
npm i -g wrangler
wrangler pages project create ai-syed-jalal-live
wrangler pages deploy frontend --project-name ai-syed-jalal-live
```

Then set these in the Cloudflare dashboard (Settings → Environment variables /
Secrets), never in a file you commit:

- `DATABASE_URL` — a Neon PostgreSQL connection string
- `CSRF_SECRET` — 32+ random characters
- `GEMINI_API_KEY` / `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` / `DEEPSEEK_API_KEY`
  — whichever you actually use

Apply the schema once against that database:

```bash
DATABASE_URL="postgres://..." npm run db:migrate
```

Open `/api/ready` afterwards. It must say **23 of 23 tables present**. If it
lists missing tables, open the Workspace Operations panel as an Admin and run
**Repair schema**, or re-run the migration.

### Option B — any static host (website only, no login or cloud AI)

Use `AI-Syed-Jalal-Website-V151-static.zip` from the `dist/` folder of the
repository. Unzip it into your host's web root (GitHub Pages, Netlify, S3,
Nginx, Cloudflare Pages…). `index.html` must stay at the root.

This copy is honest about its limits: every page that needs the API detects the
static host and shows a banner with a link to setup, instead of hanging or
showing a raw error. **The full OS integration (shortcuts, widgets, file
handlers) still works on a static host** — installation, caching and Quick Notes
are client-side. Only sign-in, saved data and cloud AI need the backend.

---

## 3. Verify it yourself

The release gates are part of the source, not a claim in a document.

```bash
npm test                 # server + frontend contracts
npm run check            # 51 static checks
npm run test:browser     # 50 real browser journeys (needs no network)
```

Expected at V151: **142 server · 80 frontend · 51 static · 50 browser**, all
green, plus `23 of 23` schema tables from an empty database.

---

## 4. What is genuinely finished, and what is not

Finished and tested here:

- The whole application above, from an empty database.
- All ten OS integrations implemented and probed live on the capabilities page.
- Service worker install, offline page serving, and cache rules that keep private
  content out of Cache Storage.
- Manifest validation with Chromium's own parser: 0 errors, 0 installability
  errors.

**Not proven here** — stated so nobody has to discover it later:

- Windows 11 widgets, ChromeOS tab strips, ChromeOS note taking and the Edge side
  panel were **not run on those operating systems**. No such device was available.
  The declarations are spec-correct and the service worker handles every widget
  event, but "shipped" for those four means implemented and tested where a
  browser could be tested.
- Live provider calls, live Google Search grounding, production load and
  penetration testing, and physical-device voice testing.
- The repository's own `worker/index.js` is a **gateway stub**: it returns a
  clear 503 until `BACKEND_API_URL` is set. The real API is the Pages Functions
  code in `frontend/functions/`, which is what the Cloudflare Pages deployment
  above uses.
